import { useEffect, useState } from 'react';

/** useState that remembers its value in this browser (view preferences: chat width, compact view, export options…) */
export function useStored(key, fallback) {
  const [value, setValue] = useState(() => {
    try {
      const v = JSON.parse(localStorage.getItem(key));
      if (v == null) return fallback;
      return fallback && typeof fallback === 'object' && !Array.isArray(fallback) ? { ...fallback, ...v } : v;
    } catch {
      return fallback;
    }
  });
  useEffect(() => {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* private mode etc. */ }
  }, [key, value]);
  return [value, setValue];
}
