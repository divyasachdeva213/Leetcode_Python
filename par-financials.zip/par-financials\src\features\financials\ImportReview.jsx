import { useEffect, useMemo, useRef, useState } from 'react';
import * as P from '../../lib/parCore';
import { parseTable, pickSheet, readFile } from '../../lib/importer';
import { SAMPLE_TSV } from './sampleData';

const ACTION = {
  category: ['Category', 'ok'], 'sub-category': ['Sub-category', 'ok'],
  'new-category': ['New category', 'new'], 'new-sub-category': ['New sub-category', 'new'],
  updated: ['Updated', 'upd'], new: ['New line', 'new'], matched: ['No change', 'mute'],
  total: ['Total row', 'mute'], skipped: ['Skipped', 'skip'], ignored: ['Ignored', 'skip'],
};
const FILTERS = [
  ['changes', 'Changes', (x) => ['updated', 'new', 'new-category', 'new-sub-category'].includes(x.action)],
  ['all', 'All rows', () => true],
  ['skipped', 'Skipped', (x) => x.action === 'skipped' || x.action === 'ignored'],
];

/**
 * Review an import before it is applied: an uploaded .xlsx/.csv (from the panel or the chat) or rows pasted from Excel.
 * Every source row shows where it goes; nothing changes until "Apply".
 */
export default function ImportReview({ doc, template, source, onApply, onClose }) {
  const [tab, setTab] = useState(source?.kind === 'text' ? 'paste' : 'file');
  const [file, setFile] = useState(null); // { name, sheets, sheet, loading, error }
  const [text, setText] = useState(source?.kind === 'text' ? source.text : '');
  const [mode, setMode] = useState('merge');
  const [skipPlaceholders, setSkip] = useState(true);
  const [createColumns, setCreate] = useState(true);
  const [view, setView] = useState('rows');
  const [filter, setFilter] = useState('changes');
  const [over, setOver] = useState(false);
  const input = useRef(null);
  const anchorId = tab === 'paste' ? source?.anchorId || null : null;

  const load = async (f) => {
    setTab('file');
    setFile({ name: f.name, loading: true });
    try {
      const sheets = await readFile(f);
      setFile({ name: f.name, sheets, sheet: pickSheet(doc, sheets) });
    } catch (e) {
      setFile({ name: f.name, error: e.message });
    }
  };
  useEffect(() => { if (source?.kind === 'file') load(source.file); }, [source]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    const k = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [onClose]);

  const rows = useMemo(() => {
    if (tab === 'file') return file?.sheets?.[file.sheet]?.rows || null;
    return text.trim() ? P.parseTSV(text) : null;
  }, [tab, file, text]);
  const result = useMemo(() => (rows ? parseTable(doc, rows, { mode, skipPlaceholders, createColumns, template, anchorId }) : null),
    [doc, rows, mode, skipPlaceholders, createColumns, template, anchorId]);
  const rep = result?.report, sum = rep?.summary;
  const changes = sum ? sum.updated + sum.newLines + sum.newCategories + sum.newSubcategories + sum.newColumns : 0;
  const shown = rep ? rep.rows.filter(FILTERS.find((f) => f[0] === filter)[2]) : [];
  const anchorLabel = anchorId ? P.pathLabel(doc, anchorId) : null;

  const drop = (e) => {
    e.preventDefault();
    setOver(false);
    const f = e.dataTransfer.files?.[0];
    if (f) load(f);
  };

  return (
    <div className="overlay" role="dialog" aria-label="Import into Financials">
      <div className="ov-head">
        <h3>Import into Financials</h3>
        <div className="seg sm">
          <button className={tab === 'file' ? 'on' : ''} onClick={() => setTab('file')}>⇪ Excel / CSV file</button>
          <button className={tab === 'paste' ? 'on' : ''} onClick={() => setTab('paste')}>⧉ Paste from Excel</button>
        </div>
        <span className="grow" />
        <button className="ico big" title="Close (Esc)" onClick={onClose}>✕</button>
      </div>

      <div className="ov-body">
        <div className="imp-src">
          {tab === 'file' ? (
            <div className={`dropzone${over ? ' over' : ''}`} onDragOver={(e) => { e.preventDefault(); setOver(true); }} onDragLeave={() => setOver(false)} onDrop={drop}>
              {!file && <span>Drop an Excel file here, or <button className="link" onClick={() => input.current.click()}>browse…</button><small>.xlsx or .csv – for example a filled PAR Financial Template</small></span>}
              {file?.loading && <span><span className="spin" />Reading {file.name}…</span>}
              {file?.error && <span className="err">{file.error} <button className="link" onClick={() => input.current.click()}>Choose another file</button></span>}
              {file?.sheets && (
                <span className="fileinfo">
                  <b>📄 {file.name}</b>
                  {file.sheets.length > 1 && (
                    <select value={file.sheet} onChange={(e) => setFile({ ...file, sheet: +e.target.value })}>
                      {file.sheets.map((s, i) => <option key={i} value={i}>{s.name}{s.hidden ? ' (hidden)' : ''}</option>)}
                    </select>
                  )}
                  {rep?.headerRow ? <span className="muted">header row {rep.headerRow}</span> : <span className="muted">no header row found</span>}
                  <button className="link" onClick={() => input.current.click()}>Change file</button>
                </span>
              )}
              <input ref={input} type="file" hidden accept=".xlsx,.xlsm,.csv,.tsv,.txt,.xls" onChange={(e) => { if (e.target.files[0]) load(e.target.files[0]); e.target.value = ''; }} />
            </div>
          ) : (
            <div className="fld">
              <label>
                Rows copied from Excel{anchorLabel ? <> – lines without a category go into <b>{anchorLabel}</b></> : ''}
                <button className="link" type="button" onClick={() => setText(SAMPLE_TSV)}>load example</button>
              </label>
              <textarea value={text} autoFocus={!text} placeholder="Click here and press Ctrl+V. Headers are optional; category rows, “Xyz Items:” rows and “Total …” rows are recognised." onChange={(e) => setText(e.target.value)} />
            </div>
          )}
          <div className="imp-opts">
            <div className="radios">
              <label><input type="radio" checked={mode === 'merge'} onChange={() => setMode('merge')} />
                <span><b>Update &amp; add</b><small>Amounts and notes in the file update matching lines; new lines are added. Blank and 0 cells keep what is already here.</small></span></label>
              <label><input type="radio" checked={mode === 'replace'} onChange={() => setMode('replace')} />
                <span><b>Replace with this file</b><small>Start from the blank template and take the file exactly as it is.</small></span></label>
            </div>
            <label className="chk"><input type="checkbox" checked={skipPlaceholders} onChange={(e) => setSkip(e.target.checked)} /> Skip empty “Item 1…4” rows</label>
            <label className="chk"><input type="checkbox" checked={createColumns} onChange={(e) => setCreate(e.target.checked)} /> Add columns for unknown headers (e.g. FY 6)</label>
          </div>
        </div>

        {!rep ? <div className="placeholder sm">{tab === 'file' ? 'Choose a file to see where each row will go.' : 'Paste rows to see where each row will go.'}</div> : (
          <>
            <div className="imp-sum">
              <span className="pill upd">{sum.updated} updated</span>
              <span className="pill new">{sum.newLines} new line{sum.newLines === 1 ? '' : 's'}</span>
              {sum.newCategories + sum.newSubcategories > 0 && <span className="pill new">{sum.newCategories + sum.newSubcategories} new (sub-)categor{sum.newCategories + sum.newSubcategories === 1 ? 'y' : 'ies'}</span>}
              {sum.newColumns > 0 && <span className="pill new">{sum.newColumns} new column{sum.newColumns === 1 ? '' : 's'}</span>}
              <span className="pill mute">{sum.matched} unchanged</span>
              <span className="pill skip">{sum.skipped + sum.ignored} skipped</span>
              <span className="pill mute">{sum.totals} total row{sum.totals === 1 ? '' : 's'} recognised</span>
              {rep.warnings.length > 0 && <span className="pill warn">⚠ {rep.warnings.length} to check</span>}
            </div>
            {rep.warnings.length > 0 && <ul className="imp-warn">{rep.warnings.map((w, i) => <li key={i}>{w}</li>)}</ul>}
            {rep.columns.length > 0 && (
              <div className="imp-cols">
                <span className="muted">Columns:</span>
                {rep.columns.map((c, i) => (
                  <span key={i} className={`chip ${c.isNew ? 'new' : c.to ? 'ok' : 'off'}`} title={c.note || (c.to ? `→ ${c.label}` : '')}>
                    {c.from}{c.isNew ? ' (new)' : c.to && c.from !== c.label ? ` → ${c.label}` : ''}
                  </span>
                ))}
              </div>
            )}
            <div className="imp-tabs">
              <div className="seg sm">
                <button className={view === 'rows' ? 'on' : ''} onClick={() => setView('rows')}>Row by row</button>
                <button className={view === 'tree' ? 'on' : ''} onClick={() => setView('tree')}>Result</button>
              </div>
              {view === 'rows' && (
                <div className="seg sm">
                  {FILTERS.map(([k, l, f]) => <button key={k} className={filter === k ? 'on' : ''} onClick={() => setFilter(k)}>{l} ({rep.rows.filter(f).length})</button>)}
                </div>
              )}
            </div>
            {view === 'rows' ? (
              <div className="imp-table">
                <table>
                  <thead><tr><th>Row</th><th>In the file</th><th>What happens</th><th>Placed in</th></tr></thead>
                  <tbody>
                    {shown.map((x, i) => (
                      <tr key={i}>
                        <td className="num">{x.row}</td>
                        <td>{x.label || <i className="muted">(no label)</i>}</td>
                        <td><span className={`pill ${ACTION[x.action][1]}`}>{ACTION[x.action][0]}</span>{x.note && <small className="muted"> {x.note}</small>}</td>
                        <td className="muted">{x.path}</td>
                      </tr>
                    ))}
                    {!shown.length && <tr><td colSpan={4} className="muted">Nothing in this view.</td></tr>}
                  </tbody>
                </table>
              </div>
            ) : <ResultTree doc={result.doc} rep={rep} />}
          </>
        )}
      </div>

      <div className="ov-foot">
        <span className="muted">{rep ? (changes ? `${changes} change${changes === 1 ? '' : 's'} will be applied – you can undo it.` : 'Nothing to change.') : ''}</span>
        <span className="grow" />
        <button className="btn" onClick={onClose}>Cancel</button>
        <button className="btn pri" disabled={!result} onClick={() => onApply(result, { name: tab === 'file' ? file?.name : 'pasted rows' })}>Apply import</button>
      </div>
    </div>
  );
}

/** what the financials will look like: categories with totals, lines that hold data, new / updated marked */
function ResultTree({ doc, rep }) {
  const T = useMemo(() => P.computeTotals(doc), [doc]);
  const rt = P.rowTotalCol(doc);
  const marks = new Map(rep.rows.filter((x) => x.id).map((x) => [x.id, x.action]));
  const out = [];
  const rec = (nodes, depth) => nodes.forEach((n) => {
    const m = marks.get(n.id);
    if (P.isLine(n) && depth > 0 && P.isEmptyLine(doc, n) && !m) return;
    out.push(
      <div key={n.id} className={`tr-row${n.type === 'group' && !P.isRollup(n) ? ' g' : ''}`} style={{ paddingLeft: depth * 16 }}>
        <span>{n.label}</span>
        {m && ['new', 'new-category', 'new-sub-category'].includes(m) && <span className="pill new">new</span>}
        {m === 'updated' && <span className="pill upd">updated</span>}
        <span className="v">{P.fmt(rt ? T[n.id][rt.id] : 0)}</span>
      </div>,
    );
    if (n.type === 'group') rec(n.children, depth + 1);
  });
  rec(doc.nodes, 0);
  return <div className="tree">{out}</div>;
}
