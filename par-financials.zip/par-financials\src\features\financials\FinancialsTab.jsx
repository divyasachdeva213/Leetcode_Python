import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { produce } from 'immer';
import * as P from '../../lib/parCore';
import * as Ops from '../../lib/docOps';
import { isStructured, parseTable } from '../../lib/importer';
import { EXPORT_DEFAULTS } from '../../lib/sheetLayout';
import { exportBlankTemplate, exportXlsx, downloadBlob } from '../../lib/exportXlsx';
import { useFinancialDoc, toPayload, mergeInstance } from '../../state/useFinancialDoc';
import { useStored } from '../../state/useStored';
import { Menu, useUI } from '../../components/ui';
import FinancialGrid from './FinancialGrid';
import PreviewSheet from './PreviewSheet';
import JsonView from './JsonView';
import ImportReview from './ImportReview';
import { AddDialog, ColumnModal, ExportDialog, GroupModal } from './modals';

const time = (iso) => (iso ? new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '');
const span = (labels) => (labels.length > 1 ? `${labels[0]} – ${labels[labels.length - 1]}` : labels[0]);

/** "Fiscal years [−] 5 [+]": type a number (e.g. 15) or step; the form's FY 1–5 always stay */
function YearsControl({ doc, onChange }) {
  const { count, min, max } = Ops.yearRange(doc);
  const [draft, setDraft] = useState(null);
  const skipBlur = useRef(false);
  const commit = (v) => {
    setDraft(null);
    const n = parseInt(v, 10);
    if (Number.isFinite(n) && n !== count) onChange(n);
  };
  return (
    <span className="years" title={`Number of fiscal-year columns (${min}–${max}). New years are added as FY ${count + 1}, FY ${count + 2} … and count in every total.`}>
      Fiscal years
      <button className="btn sm icon" aria-label="One year less" disabled={count <= min} onClick={() => onChange(count - 1)}>−</button>
      <input className="yearsin" inputMode="numeric" aria-label="Number of fiscal years" value={draft ?? count}
        onFocus={(e) => e.target.select()} onChange={(e) => setDraft(e.target.value.replace(/\D/g, '').slice(0, 2))}
        onBlur={(e) => { if (skipBlur.current) { skipBlur.current = false; setDraft(null); return; } commit(e.target.value); }}
        onKeyDown={(e) => {
          if (e.key === 'Enter') e.currentTarget.blur();
          if (e.key === 'Escape') { skipBlur.current = true; e.currentTarget.blur(); }
        }} />
      <button className="btn sm icon" aria-label="One year more" disabled={count >= max} onClick={() => onChange(count + 1)}>＋</button>
    </span>
  );
}

/**
 * Financials panel. Mount = load template + saved instance, then everything renders from `doc`.
 * inbox: a file or pasted text handed over from the chat panel → opens the import review.
 * onActivity(message): posts what happened (imports, exports, conflicts) back to the chat.
 */
export default function FinancialsTab({ parId, inbox, onInboxDone, onActivity = () => {} }) {
  const [autosave, setAutosave] = useStored('par.autosave', true);
  const fin = useFinancialDoc(parId, { autosave });
  const { doc, update } = fin;
  const { toast, confirm } = useUI();

  const [mode, setMode] = useState('edit'); // edit | preview | json
  const [collapsedIds, setCollapsedIds] = useStored(`par.${parId}.collapsed`, []);
  const collapsed = useMemo(() => new Set(collapsedIds), [collapsedIds]);
  const [hideEmpty, setHideEmpty] = useStored('par.hideEmpty', false);
  const [compact, setCompact] = useStored('par.compact', true);
  const [exportOpts, setExportOpts] = useStored('par.exportOptions', EXPORT_DEFAULTS);
  const [menu, setMenu] = useState(null); // {anchor, items}
  const [modal, setModal] = useState(null); // {kind, ...}
  const [importSrc, setImportSrc] = useState(null); // {kind:'file', file} | {kind:'text', text, anchorId} | {kind:'new'}
  const [focusId, setFocusId] = useState(null);
  const [fileOver, setFileOver] = useState(false);
  const lastRow = useRef(null); // the row last worked in → where "Add" puts things by default

  const expand = useCallback((...ids) => setCollapsedIds((cur) => cur.filter((x) => !ids.includes(x))), [setCollapsedIds]);

  // a file / pasted rows handed over from the chat
  useEffect(() => {
    if (!inbox || fin.status !== 'ready') return;
    setMode('edit');
    setImportSrc(inbox.kind === 'file' ? { kind: 'file', file: inbox.file } : { kind: 'text', text: inbox.text });
    onInboxDone?.();
  }, [inbox, fin.status]); // eslint-disable-line react-hooks/exhaustive-deps

  // keyboard shortcuts (outside inputs)
  useEffect(() => {
    const k = (e) => {
      if (!(e.ctrlKey || e.metaKey) || e.target.closest?.('input,textarea,.modal,.overlay')) return;
      if (e.key === 'z' && !e.shiftKey) { e.preventDefault(); fin.undo(); }
      else if (e.key === 'y' || (e.key === 'z' && e.shiftKey)) { e.preventDefault(); fin.redo(); }
      else if (e.key === 's') { e.preventDefault(); fin.save(); }
    };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [fin]);

  const totals = useMemo(() => (doc ? P.computeTotals(doc) : {}), [doc]);
  const issues = useMemo(() => (doc ? P.validate(doc) : {}), [doc]);

  /** scroll to a row (expanding its categories) and put the cursor in it (a given column, or the first cell) */
  const jumpTo = useCallback((id, focus = true, col = null) => {
    setMode('edit');
    expand(...P.pathTo(doc, id).map((n) => n.id).filter((x) => x !== id || !focus));
    setTimeout(() => {
      const row = document.getElementById(`row-${id}`);
      if (!row) return;
      row.scrollIntoView({ block: 'center', behavior: 'smooth' });
      if (focus) (row.querySelector(col ? `input.cell[data-col="${col}"]` : 'input.cell') || row.querySelector('input.cell'))?.focus({ preventScroll: true });
      row.classList.add('flash');
      setTimeout(() => row.classList.remove('flash'), 1400);
    }, 60);
  }, [doc, expand]);

  /** the (sub-)category of the row last worked in */
  const contextGroup = useCallback(() => {
    const f = lastRow.current && P.findNode(doc, lastRow.current);
    if (!f) return null;
    if (f.node.type === 'group' && !P.isRollup(f.node)) return f.node.id;
    return P.pathTo(doc, f.node.id).slice(0, -1).reverse().find((g) => !P.isRollup(g))?.id || null;
  }, [doc]);

  // ── structural actions ───────────────────────────────────────────────
  const addItem = useCallback((groupId, afterId, label) => {
    const it = P.newItem(label || undefined);
    update((d) => { Ops.addItem(d, groupId, afterId, it); });
    if (groupId) expand(...P.pathTo(doc, groupId).map((n) => n.id));
    if (hideEmpty) { setHideEmpty(false); toast('Showing all lines so you can fill in the new one'); }
    if (label) jumpTo(it.id, true, P.periodCols(doc)[0]?.id);
    else setFocusId(it.id);
  }, [doc, update, expand, hideEmpty, setHideEmpty, toast, jumpTo]);

  const addGroup = useCallback((parentId, label) => {
    const g = P.newGroup(label || (parentId ? 'New sub-category' : 'New category'));
    if (parentId) g.total.show = false;
    update((d) => { Ops.addGroup(d, parentId, g); });
    if (parentId) expand(...P.pathTo(doc, parentId).map((n) => n.id));
    if (label) jumpTo(g.id, false);
    else setFocusId(g.id);
  }, [doc, update, expand, jumpTo]);

  const addTopItem = useCallback(() => {
    const it = P.newItem('New single-line category');
    update((d) => { d.nodes.push(it); });
    setFocusId(it.id);
  }, [update]);

  const openAdd = (kind) => { setMode('edit'); setModal({ kind: 'add', initial: { kind, parentId: contextGroup() } }); };
  const addFromDialog = ({ kind, name, parentId }) => {
    setModal(null);
    if (kind === 'line') addItem(parentId, null, name);
    else addGroup(kind === 'sub' ? parentId : null, name);
  };

  /** Ctrl+Enter: a new line below the current one (or at the end of a category's lines) */
  const insertBelow = useCallback((id) => {
    const f = id && P.findNode(doc, id);
    if (!f) return;
    if (f.node.type === 'group' && !P.isRollup(f.node)) { if (f.node.perms?.add_items !== false) addItem(f.node.id); return; }
    if (f.parent) addItem(f.parent.id, f.node.id);
  }, [doc, addItem]);

  /** "Hardware" → its row becomes the subtotal of sub-items; focus the new sub-item */
  const breakDown = useCallback((itemId) => {
    let childId;
    update(produce(doc, (d) => { childId = Ops.convertToGroup(d, itemId); }));
    expand(itemId);
    setFocusId(childId);
    toast('This line is now the subtotal of its sub-items – add more with ＋');
  }, [doc, update, expand, toast]);

  const mergeBack = useCallback(async (groupId) => {
    const g = P.findNode(doc, groupId).node;
    if (g.children.length > 1 && !(await confirm(`Merge ${g.children.length} sub-items into “${g.label}”?`, 'Amounts are added up into one line; notes are joined. You can undo this.', 'Merge'))) return;
    update((d) => { Ops.convertToItem(d, groupId); });
  }, [doc, update, confirm]);

  const removeNode = useCallback(async (id) => {
    const { node } = P.findNode(doc, id);
    if (!P.isEmptyNode(doc, node) && !(await confirm(`Delete “${node.label}”?`, 'It contains values. You can undo this.'))) return;
    update((d) => Ops.deleteNode(d, id));
  }, [doc, update, confirm]);

  /** the ＋ on a category / sub-category row */
  const addMenu = useCallback((anchor, id) => {
    const n = P.findNode(doc, id).node;
    setMenu({ anchor, items: [
      { label: 'Add line item', onClick: () => addItem(id), disabled: n.perms?.add_items === false },
      { label: 'Add sub-category', onClick: () => addGroup(id), disabled: !n.perms?.add_groups },
      '-',
      { label: 'Paste lines from Excel…', onClick: () => setImportSrc({ kind: 'text', text: '', anchorId: id }), disabled: n.perms?.add_items === false },
    ] });
  }, [doc, addItem, addGroup]);

  /** ⋯ or right-click on a row */
  const nodeMenu = useCallback((anchor, id) => {
    const { node: n, depth, parent } = P.findNode(doc, id);
    const locked = n.perms?.delete === false;
    const move = (dir) => update((d) => Ops.moveNode(d, id, dir));
    const moves = [
      { label: 'Move up', onClick: () => move(-1), disabled: locked || Ops.moveTarget(doc, id, -1) < 0 },
      { label: 'Move down', onClick: () => move(1), disabled: locked || Ops.moveTarget(doc, id, 1) < 0 },
    ];
    const rollup = P.isRollup(n);
    const items = n.type === 'item' ? [
      { label: 'Insert line below', hint: 'Ctrl+Enter', onClick: () => addItem(parent?.id, id), disabled: !parent },
      ...(depth > 0 && !P.isRollup(parent) ? [{ label: 'Split into sub-items (this row becomes their subtotal)', onClick: () => breakDown(id) }] : []),
      { label: 'Duplicate', onClick: () => update((d) => Ops.duplicateItem(d, id)), disabled: !parent },
      '-', ...moves, '-',
      { label: locked ? 'Delete (part of the form)' : 'Delete line', danger: true, disabled: locked, onClick: () => removeNode(id) },
    ] : rollup ? [
      { label: 'Add sub-item', onClick: () => addItem(id) },
      { label: 'Merge sub-items back into one line', onClick: () => mergeBack(id), disabled: n.children.some((c) => c.type !== 'item') },
      '-', ...moves, '-',
      { label: locked ? 'Delete (part of the form)' : 'Delete line and its sub-items', danger: true, disabled: locked, onClick: () => removeNode(id) },
    ] : [
      { label: 'Add line item', onClick: () => addItem(id), disabled: n.perms?.add_items === false },
      { label: 'Add sub-category', onClick: () => addGroup(id), disabled: !n.perms?.add_groups },
      { label: 'Paste lines from Excel…', onClick: () => setImportSrc({ kind: 'text', text: '', anchorId: id }), disabled: n.perms?.add_items === false },
      '-',
      { label: n.perms?.rename === false ? 'Definition / total label…' : 'Rename, definition, total label…', onClick: () => setModal({ kind: 'group', id }) },
      { label: 'Show a “Total” row', check: !!n.total?.show,
        onClick: () => update((d) => Ops.updateGroup(d, id, { total: { label: n.total?.label || `Total ${n.label}`, show: !n.total?.show } })) },
      ...(depth > 0 ? [{ label: 'Count in the parent total', check: !n.exclude_from_parent_total,
        onClick: () => update((d) => Ops.updateGroup(d, id, { exclude_from_parent_total: !n.exclude_from_parent_total })) }] : []),
      '-', ...moves, '-',
      { label: locked ? 'Delete (part of the form)' : depth ? 'Delete sub-category' : 'Delete category', danger: true, disabled: locked, onClick: () => removeNode(id) },
    ];
    setMenu({ anchor, items });
  }, [doc, update, addItem, addGroup, removeNode, breakDown, mergeBack]);

  const colMenu = useCallback((anchor, colId) => {
    const i = doc.columns.findIndex((c) => c.id === colId), c = doc.columns[i];
    const locked = c.origin !== 'user';
    setMenu({ anchor, items: [
      { label: 'Edit column…', onClick: () => setModal({ kind: 'column', colId }) },
      ...(c.type === 'amount' && !(c.role === 'period' && (locked || P.fyNumber(c.label) != null))
        ? [{ label: 'Include in row Total (Σ)', check: c.role === 'period', onClick: () => update((d) => Ops.togglePeriod(d, colId)) }] : []),
      '-',
      { label: 'Move left', disabled: i <= 1, onClick: () => update((d) => Ops.moveColumn(d, colId, -1)) },
      { label: 'Move right', disabled: i === doc.columns.length - 1, onClick: () => update((d) => Ops.moveColumn(d, colId, 1)) },
      '-',
      c.role === 'period'
        ? { label: locked ? 'Remove year (the form’s FY 1–5 always stay)' : `Remove ${c.label}`, danger: !locked, disabled: locked,
          onClick: async () => {
            const held = [...P.walk(doc.nodes)].some(([n]) => n.values?.[colId] != null && String(n.values[colId]).trim() !== '');
            if (held && !(await confirm(`Remove ${c.label}?`, 'Its amounts will be deleted and the later years renumbered. You can undo this.', 'Remove year'))) return;
            update((d) => Ops.removeColumn(d, colId));
          } }
        : { label: locked ? 'Hide column (also hidden in the export)' : 'Delete column', danger: !locked, disabled: c.role === 'row_total',
          onClick: async () => {
            if (!locked && !(await confirm(`Delete column “${c.label}”?`, 'Values in this column will be removed. You can undo this.'))) return;
            update((d) => Ops.removeColumn(d, colId));
          } },
      ...(doc.columns.some((x) => x.visible === false) ? ['-', { label: 'Show hidden columns', onClick: () => update(Ops.showAllColumns) }] : []),
    ] });
  }, [doc, update, confirm]);

  /** add or remove fiscal years; years that hold amounts are only removed after a confirmation */
  const changeYears = useCallback(async (n) => {
    const { min, max } = Ops.yearRange(doc);
    const target = Math.max(min, Math.min(max, n));
    const going = Ops.yearsToRemove(doc, target), lost = going.filter((y) => y.hasValues);
    if (lost.length && !(await confirm(`Go down to ${target} fiscal years?`,
      `${span(going.map((y) => y.label))} will be removed. ${span(lost.map((y) => y.label))} ${lost.length > 1 ? 'hold' : 'holds'} `
      + `${P.fmt(lost.reduce((a, y) => a + y.total, 0))} in total, which will be deleted. You can undo this.`, 'Remove years'))) return;
    let res;
    update(produce(doc, (d) => { res = Ops.setYearCount(d, target); }));
    if (res.added.length) toast(`Added ${span(res.added)} – every total includes ${res.added.length > 1 ? 'them' : 'it'}`);
    else if (res.removed.length) toast(`Removed ${span(res.removed)}`);
  }, [doc, update, confirm, toast]);

  // ── paste straight into the grid ─────────────────────────────────────
  const onGridPaste = useCallback((e) => {
    const el = e.target.closest?.('[data-id][data-col]');
    if (!el) return;
    const text = e.clipboardData.getData('text/plain').replace(/\r?\n$/, '');
    const isInput = el.matches('input.cell');
    if (isInput && !/[\t\n]/.test(text)) return; // a single value → normal paste into the cell
    e.preventDefault();
    const rows = P.parseTSV(text).filter((r) => r.some((v) => String(v).trim() !== ''));
    if (!rows.length) return;
    const { node, parent } = P.findNode(doc, el.dataset.id);
    const groupId = node.type === 'group' && !P.isRollup(node) ? node.id : parent && !P.isRollup(parent) ? parent.id : null;
    if (isStructured(doc, rows)) { setImportSrc({ kind: 'text', text, anchorId: groupId }); return; }
    const col = doc.columns.find((c) => c.id === el.dataset.col);
    const where = groupId ? P.findNode(doc, groupId).node.label : node.label;
    if (col.role === 'label' && groupId && rows.every((r) => String(r[0] ?? '').trim() && P.parseNumber(r[0]) == null)) {
      // rows with names: update the lines of this category that have the same name, add the others
      const { doc: next, report } = parseTable(doc, rows, { anchorId: groupId });
      update(() => next);
      toast(`Pasted ${rows.length} row${rows.length > 1 ? 's' : ''} into ${where}: ${report.summary.updated} updated, ${report.summary.newLines} new`);
    } else {
      let res;
      update(produce(doc, (d) => { res = Ops.pasteBlock(d, el.dataset.id, el.dataset.col, rows, { append: el.dataset.append === '1' }); }));
      toast(`Pasted ${res.rows} × ${res.cols}${res.created ? ` – ${res.created} new line${res.created > 1 ? 's' : ''} in ${where}` : ''}`
        + `${res.years.length ? ` – added ${span(res.years)}` : ''}`);
    }
    if (groupId) expand(groupId);
    if (isInput) el.blur();
  }, [doc, update, toast, expand]);

  // ── import / export / save ───────────────────────────────────────────
  const applyImport = (result, meta) => {
    update(() => result.doc);
    setImportSrc(null);
    const s = result.report.summary, groups = s.newCategories + s.newSubcategories;
    const msg = `Imported ${meta.name}: ${s.updated} line${s.updated === 1 ? '' : 's'} updated, ${s.newLines} new`
      + `${groups ? `, ${groups} new (sub-)categor${groups === 1 ? 'y' : 'ies'}` : ''}${s.newColumns ? `, ${s.newColumns} new column${s.newColumns === 1 ? '' : 's'}` : ''}`
      + `${s.skipped ? ` · ${s.skipped} empty row${s.skipped === 1 ? '' : 's'} skipped` : ''}`;
    toast(msg);
    onActivity({ role: 'system', tone: 'ok', text: `${msg}. Undo is available in the toolbar.` });
  };
  const doExport = async (fileName) => {
    setModal(null);
    try {
      await exportXlsx(doc, fileName, exportOpts);
      toast(`Exported ${fileName}`);
      onActivity({ role: 'system', tone: 'ok', text: `Exported ${fileName}${exportOpts.removeEmptyLines ? ' (empty lines left out)' : ''}.` });
    } catch (err) {
      console.error(err);
      toast(`Export failed: ${err.message}`);
    }
  };
  const doBlank = async () => {
    try { await exportBlankTemplate(fin.template, 'PAR_Financial_Template_blank.xlsx'); toast('Downloaded the blank template'); }
    catch (err) { toast(`Download failed: ${err.message}`); }
  };
  const save = async () => { const m = await fin.save(); if (m) toast(`Saved version ${m.version}`); };

  useEffect(() => {
    if (fin.conflict) onActivity({ role: 'system', tone: 'warn', text: `Financials were saved elsewhere (version ${fin.conflict.current_version}). Autosave is paused until you choose which version to keep.` });
  }, [fin.conflict]); // eslint-disable-line react-hooks/exhaustive-deps

  // drop an Excel file anywhere on the panel
  const onDragOver = (e) => { if ([...(e.dataTransfer?.types || [])].includes('Files')) { e.preventDefault(); setFileOver(true); } };
  const onDragLeave = (e) => { if (!e.currentTarget.contains(e.relatedTarget)) setFileOver(false); };
  const onDrop = (e) => {
    if (!e.dataTransfer.files?.length) return;
    e.preventDefault();
    setFileOver(false);
    setImportSrc({ kind: 'file', file: e.dataTransfer.files[0] });
  };

  if (fin.status === 'loading' || fin.status === 'idle') return <div className="loading"><span className="spin" />Loading the financial template…</div>;
  if (fin.status === 'error') return <div className="placeholder">Could not load financials: {fin.error} <button className="btn" onClick={fin.reload}>Retry</button></div>;

  const rt = P.rowTotalCol(doc), pc = P.periodCols(doc);
  const issueList = Object.entries(issues);
  const lineCount = [...P.walk(doc.nodes)].filter(([n]) => n.type === 'item').length;
  const editing = mode === 'edit';
  const status = fin.dirty ? (autosave && !fin.conflict ? 'Saving…' : 'Unsaved changes')
    : fin.savedMeta ? `Saved · version ${fin.savedMeta.version} · ${time(fin.savedMeta.saved_at)}` : 'Not saved yet';
  const groupIds = [...P.walk(doc.nodes)].filter(([n]) => n.type === 'group').map(([n]) => n.id);

  return (
    <div className="fin" onDragOver={onDragOver} onDragLeave={onDragLeave} onDrop={onDrop}
      onFocusCapture={(e) => { const r = e.target.closest?.('tr[data-row]'); if (r) lastRow.current = r.dataset.row; }}>
      <div className="toolbar">
        <div className="seg" role="tablist">
          {[['edit', 'Edit'], ['preview', 'Excel preview']].map(([k, l]) => (
            <button key={k} role="tab" aria-selected={mode === k} className={mode === k ? 'on' : ''} onClick={() => setMode(k)}>{l}</button>
          ))}
        </div>
        <button className="btn" onClick={(e) => setMenu({ anchor: e.currentTarget, items: [
          { label: 'Category', onClick: () => addGroup(null) },
          { label: 'Sub-category…', onClick: () => openAdd('sub') },
          { label: 'Line item…', hint: 'Ctrl+Enter', onClick: () => openAdd('line') },
          '-',
          { label: 'Single-line category', onClick: addTopItem },
        ] })}>＋ Add ▾</button>
        <button className="btn" onClick={(e) => setMenu({ anchor: e.currentTarget, items: [
          { label: 'Upload an Excel / CSV file…', onClick: () => setImportSrc({ kind: 'new' }) },
          { label: 'Paste rows from Excel…', onClick: () => setImportSrc({ kind: 'text', text: '' }) },
        ] })}>⇪ Import ▾</button>
        <button className="btn" onClick={(e) => setMenu({ anchor: e.currentTarget, items: [
          { label: 'Export to Excel…', onClick: () => setModal({ kind: 'export' }) },
          { label: 'Preview the Excel sheet', onClick: () => setMode('preview') },
          '-',
          { label: 'Download the blank template (empty form)', onClick: doBlank },
        ] })}>⬇ Export ▾</button>
        <span className="vsep" />
        <button className="btn icon" title="Undo (Ctrl+Z)" aria-label="Undo" disabled={!fin.canUndo} onClick={fin.undo}>↶</button>
        <button className="btn icon" title="Redo (Ctrl+Y)" aria-label="Redo" disabled={!fin.canRedo} onClick={fin.redo}>↷</button>
        <button className="btn icon" title="More" aria-label="More" onClick={(e) => setMenu({ anchor: e.currentTarget, items: [
          { label: 'Add column…', onClick: () => setModal({ kind: 'column' }), disabled: !editing },
          { label: 'Autosave', check: autosave, onClick: () => setAutosave(!autosave) },
          { label: 'Saved data (JSON)', check: mode === 'json', onClick: () => setMode(mode === 'json' ? 'edit' : 'json') },
          '-',
          { label: 'Reset to the blank template…', danger: true, onClick: async () => {
            if (await confirm('Reset to the blank template?', 'All categories, lines and values go back to the template. You can undo this.', 'Reset')) update(() => mergeInstance(fin.template, null));
          } },
        ] })}>⋯</button>
        <span className="grow" />
        <span className={`status${fin.dirty ? ' dirty' : ''}`}>{status}</span>
        <button className="btn pri" disabled={!fin.dirty} onClick={save}>Save</button>
      </div>

      {fin.conflict && (
        <div className="banner warn">
          <span><b>Saved elsewhere.</b> Someone{fin.conflict.saved_by ? ` (${fin.conflict.saved_by})` : ''} saved version {fin.conflict.current_version}
            {fin.conflict.saved_at ? ` at ${time(fin.conflict.saved_at)}` : ''} after you opened these financials. Autosave is paused.</span>
          <span className="grow" />
          <button className="btn sm" onClick={async () => { if (await confirm('Load the saved version?', 'Your unsaved changes here will be discarded.', 'Load saved version')) fin.reload(); }}>Load the saved version</button>
          <button className="btn sm pri" onClick={async () => { const m = await fin.save({ overwrite: true }); if (m) toast(`Saved version ${m.version}`); }}>Keep my changes</button>
        </div>
      )}
      {fin.saveError && !fin.conflict && (
        <div className="banner err"><span><b>Not saved.</b> {fin.saveError}</span><span className="grow" /><button className="btn sm" onClick={save}>Try again</button></div>
      )}

      <div className="totals">
        {doc.nodes.map((n) => (
          <button key={n.id} className="tchip" onClick={() => jumpTo(n.id, false)}
            title={[`${n.label}`, ...pc.map((c) => `${c.label}: ${P.fmt(totals[n.id][c.id]) || '-'}`)].join('\n')}>
            <span className="k">{n.label}</span>
            <span className="v">{rt ? P.fmt(totals[n.id][rt.id]) : ''}</span>
          </button>
        ))}
        <span className="grow" />
        {issueList.length > 0
          ? <button className="badge-warn" onClick={(e) => setMenu({ anchor: e.currentTarget, items: issueList.map(([id, msgs]) => ({ label: `${P.pathLabel(doc, id)} – ${msgs.join('; ')}`, onClick: () => jumpTo(id) })) })}>
              ⚠ {issueList.length} line{issueList.length > 1 ? 's' : ''} to check</button>
          : <span className="badge-ok">✓ Nothing to check</span>}
      </div>

      {editing && (
        <div className="gridopts">
          <label className="chk"><input type="checkbox" checked={hideEmpty} onChange={(e) => setHideEmpty(e.target.checked)} /> Hide empty lines</label>
          <div className="seg sm">
            <button className={compact ? 'on' : ''} onClick={() => setCompact(true)} title="Label, Total, FY columns and notes">Compact</button>
            <button className={!compact ? 'on' : ''} onClick={() => setCompact(false)} title="Every column of the form">All columns</button>
          </div>
          <YearsControl doc={doc} onChange={changeYears} />
          <button className="link" onClick={() => setCollapsedIds([])}>Expand all</button>
          <button className="link" onClick={() => setCollapsedIds(groupIds)}>Collapse all</button>
          <span className="grow" />
          <span className="hint">{lineCount} lines · {doc.config?.currency || 'CAD'} · fiscal year {doc.config?.fiscal_year_description}</span>
        </div>
      )}

      {editing && (
        <FinancialGrid
          doc={doc} totals={totals} issues={issues} collapsed={collapsed} focusId={focusId} hideEmpty={hideEmpty} compact={compact}
          update={update} commitEdit={fin.commitEdit} cancelEdit={fin.cancelEdit}
          onToggle={(id) => setCollapsedIds((cur) => (cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id]))}
          onNodeMenu={nodeMenu} onAddMenu={addMenu} onColMenu={colMenu}
          onAddItem={addItem} onAddSub={addGroup} onAddSection={() => addGroup(null)} onAddTopItem={addTopItem}
          onAddColumn={() => setModal({ kind: 'column' })} onPaste={onGridPaste} onBreakDown={breakDown} onInsertBelow={insertBelow}
          onMove={(id, parentId, index) => { update((d) => { Ops.moveNodeTo(d, id, parentId, index); }); if (parentId) expand(parentId); }}
        />
      )}
      {mode === 'preview' && <PreviewSheet doc={doc} options={exportOpts} onOptions={() => setModal({ kind: 'export' })} />}
      {mode === 'json' && (
        <JsonView parId={parId} doc={doc} template={fin.template} savedMeta={fin.savedMeta}
          onReload={async () => { await fin.reload(); setMode('edit'); toast('Re-loaded from the saved data'); }}
          onDownload={() => downloadBlob(new Blob([JSON.stringify(toPayload(parId, doc), null, 2)], { type: 'application/json' }), `PAR_Financial_${parId}.json`)}
          onLoadJson={async (f) => { const j = JSON.parse(await f.text()); update(() => mergeInstance(fin.template, j)); toast(`Loaded ${f.name}`); }}
          onReset={async () => { if (await confirm('Reset to the blank template?', 'Discards all structure changes and values (you can undo).', 'Reset')) update(() => mergeInstance(fin.template, null)); }}
        />
      )}

      {importSrc && (
        <ImportReview doc={doc} template={fin.template} source={importSrc.kind === 'new' ? null : importSrc}
          onApply={applyImport} onClose={() => setImportSrc(null)} />
      )}
      {fileOver && <div className="dropcover"><div>⇪ Drop the Excel file to import it into Financials</div></div>}
      {menu && <Menu anchor={menu.anchor} items={menu.items} onClose={() => setMenu(null)} />}

      {modal?.kind === 'add' && <AddDialog doc={doc} initial={modal.initial} onAdd={addFromDialog} onClose={() => setModal(null)} />}
      {modal?.kind === 'column' && (
        <ColumnModal doc={doc} column={modal.colId ? doc.columns.find((c) => c.id === modal.colId) : null}
          onClose={() => setModal(null)}
          onSubmit={(v) => { update((d) => { modal.colId ? Ops.updateColumn(d, modal.colId, v) : Ops.addColumn(d, v); }); setModal(null); }} />
      )}
      {modal?.kind === 'group' && (
        <GroupModal node={P.findNode(doc, modal.id).node} depth={P.findNode(doc, modal.id).depth} onClose={() => setModal(null)}
          onSubmit={(v) => { update((d) => Ops.updateGroup(d, modal.id, v)); setModal(null); }} />
      )}
      {modal?.kind === 'export' && (
        <ExportDialog doc={doc} parId={parId} options={exportOpts} onChange={setExportOpts} onClose={() => setModal(null)}
          onPreview={() => { setModal(null); setMode('preview'); }} onExport={doExport} />
      )}
    </div>
  );
}
