"""
FastAPI backend for the Financials tab (matches src/api/financialsApi.js).

    pip install fastapi uvicorn sqlalchemy openpyxl
    uvicorn main:app --reload --port 8000        # then run the UI with VITE_USE_MOCK_API=false (npm run dev:all)

Storage model
  par_financials          one JSON document per PAR (structure + values) – the source of truth
  par_financials_history  every save, for audit / restore
  par_financial_lines     flat projection (one row per line × amount column), rebuilt on each save, for SQL reporting
  financial_templates     template JSON per (template_id, version); a PAR stays on the version it was created with
Totals are never stored: they are recalculated from the document. SQLite by default; set DATABASE_URL to use
Postgres (the JSON columns become JSONB).
"""
import datetime as dt
import json
import os
import tempfile
from pathlib import Path
from typing import Literal, Optional, Union

from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import JSON, Column, Float, Integer, MetaData, String, Table, Text, create_engine, delete, insert, select, update
from sqlalchemy.dialects.postgresql import JSONB

import par_engine as E

HERE = Path(__file__).parent
DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{HERE / 'par.db'}")
MAX_NODES, MAX_COLUMNS = 5000, 60

engine = create_engine(DATABASE_URL)
JSONDoc = JSON().with_variant(JSONB(), "postgresql")
md = MetaData()
templates = Table(
    "financial_templates", md,
    Column("template_id", String(64), primary_key=True), Column("version", String(16), primary_key=True),
    Column("body", JSONDoc, nullable=False), Column("created_at", String(32)))
pars = Table(
    "par_financials", md,
    Column("par_id", String(64), primary_key=True), Column("template_id", String(64)), Column("template_version", String(16)),
    Column("body", JSONDoc, nullable=False), Column("version", Integer, nullable=False),
    Column("saved_at", String(32)), Column("saved_by", String(128)))
history = Table(
    "par_financials_history", md,
    Column("par_id", String(64), primary_key=True), Column("version", Integer, primary_key=True),
    Column("body", JSONDoc, nullable=False), Column("saved_at", String(32)), Column("saved_by", String(128)),
    Column("note", String(256)))
lines = Table(
    "par_financial_lines", md,
    Column("par_id", String(64), index=True), Column("version", Integer), Column("node_id", String(80)),
    Column("parent_id", String(80)), Column("path", Text), Column("depth", Integer), Column("label", Text),
    Column("column_id", String(80)), Column("column_label", Text), Column("amount", Float))
md.create_all(engine)


def now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


# seed the template (normally loaded by an admin from the form / template_metadata.xlsx)
_tpl = json.loads((HERE / "par_template_v3.json").read_text(encoding="utf-8"))
with engine.begin() as conn:
    key = (templates.c.template_id == _tpl["template_id"]) & (templates.c.version == _tpl["template_version"])
    if conn.execute(select(templates.c.version).where(key)).first() is None:
        conn.execute(insert(templates).values(template_id=_tpl["template_id"], version=_tpl["template_version"],
                                              body=_tpl, created_at=now()))

app = FastAPI(title="PAR Financials API")


# ───────────────────────────────────────────────────────────── payload shape
class ColumnIn(BaseModel):
    model_config = ConfigDict(extra="allow")
    id: str = Field(min_length=1, max_length=80)
    label: str = Field(max_length=200)
    type: Literal["text", "date", "amount", "formula"]
    role: Optional[Literal["label", "period", "row_total", "notes", "definition"]] = None


class NodeIn(BaseModel):
    model_config = ConfigDict(extra="allow")
    id: str = Field(min_length=1, max_length=80)
    type: Literal["group", "item"]
    label: str = Field(default="", max_length=500)
    values: dict[str, Union[float, int, str, None]] = {}
    children: list["NodeIn"] = []


class FinancialsIn(BaseModel):
    model_config = ConfigDict(extra="allow")
    template_id: str
    template_version: str
    columns: list[ColumnIn] = Field(min_length=1, max_length=MAX_COLUMNS)
    nodes: list[NodeIn]
    base_version: Optional[int] = None  # the version the client started from; a stale one is a 409


def clean_document(body: FinancialsIn) -> dict:
    """structural checks the client can't be trusted with; returns the JSON that gets stored"""
    doc = body.model_dump(exclude={"base_version"}, exclude_none=False)
    doc.pop("version", None), doc.pop("saved_at", None)
    if sum(1 for c in doc["columns"] if c.get("role") == "label") != 1:
        raise HTTPException(422, "exactly one label column is required")
    col_ids = {c["id"] for c in doc["columns"]}
    if len(col_ids) != len(doc["columns"]):
        raise HTTPException(422, "column ids must be unique")
    seen = set()
    for n, _, _ in E.walk(doc["nodes"]):
        if n["id"] in seen:
            raise HTTPException(422, f"duplicate node id {n['id']}")
        seen.add(n["id"])
        if n["type"] == "item":
            n.pop("children", None)
        n["values"] = {k: v for k, v in (n.get("values") or {}).items() if k in col_ids and v is not None}
    if len(seen) > MAX_NODES:
        raise HTTPException(422, f"too many rows (max {MAX_NODES})")
    return doc


def summary(doc: dict) -> dict:
    totals = E.compute_totals(doc)
    rt = next((c["id"] for c in doc["columns"] if c.get("role") == "row_total"), None)
    return {"issues": E.validate(doc),
            "totals": {n["id"]: {"label": n.get("label"), "total": totals[n["id"]].get(rt, 0)} for n in doc["nodes"]}}


def write_version(conn, par_id: str, doc: dict, version: int, user: str, note: Optional[str] = None) -> str:
    saved_at = now()
    values = dict(template_id=doc.get("template_id"), template_version=doc.get("template_version"), body=doc,
                  version=version, saved_at=saved_at, saved_by=user)
    if version == 1:
        conn.execute(insert(pars).values(par_id=par_id, **values))
    else:
        conn.execute(update(pars).where(pars.c.par_id == par_id).values(**values))
    conn.execute(insert(history).values(par_id=par_id, version=version, body=doc, saved_at=saved_at, saved_by=user, note=note))
    conn.execute(delete(lines).where(lines.c.par_id == par_id))
    rows = [{"par_id": par_id, "version": version, **r} for r in E.project_lines(doc)]
    if rows:
        conn.execute(insert(lines), rows)
    return saved_at


# ───────────────────────────────────────────────────────────── endpoints
@app.get("/api/templates/{template_id}/versions/{version}")
def get_template(template_id: str, version: str):
    with engine.connect() as conn:
        row = conn.execute(select(templates.c.body).where((templates.c.template_id == template_id) & (templates.c.version == version))).first()
    if not row:
        raise HTTPException(404, f"template {template_id} v{version} not found")
    return row.body


@app.get("/api/templates/{template_id}/latest")
def latest_template(template_id: str):
    with engine.connect() as conn:
        rows = conn.execute(select(templates.c.version, templates.c.body).where(templates.c.template_id == template_id)).all()
    if not rows:
        raise HTTPException(404, f"template {template_id} not found")
    return max(rows, key=lambda r: [int(x) for x in r.version.split(".") if x.isdigit()]).body


@app.get("/api/pars/{par_id}/financials")
def get_financials(par_id: str):
    with engine.connect() as conn:
        row = conn.execute(select(pars.c.body, pars.c.version, pars.c.saved_at).where(pars.c.par_id == par_id)).first()
    if not row:
        raise HTTPException(404, "no financials saved for this PAR yet")
    return {**row.body, "version": row.version, "saved_at": row.saved_at}


@app.put("/api/pars/{par_id}/financials")
def save_financials(par_id: str, body: FinancialsIn, x_user: Optional[str] = Header(default=None)):
    doc = clean_document(body)
    with engine.begin() as conn:
        cur = conn.execute(select(pars.c.version, pars.c.saved_at, pars.c.saved_by).where(pars.c.par_id == par_id)).first()
        if cur is not None and body.base_version != cur.version:
            raise HTTPException(409, {"message": "This PAR's financials were saved by someone else in the meantime.",
                                      "current_version": cur.version, "saved_at": cur.saved_at, "saved_by": cur.saved_by})
        version = (cur.version if cur else 0) + 1
        saved_at = write_version(conn, par_id, doc, version, x_user or "anonymous")
    return {"version": version, "saved_at": saved_at, **summary(doc)}


@app.get("/api/pars/{par_id}/financials/versions")
def list_versions(par_id: str):
    with engine.connect() as conn:
        rows = conn.execute(select(history.c.version, history.c.saved_at, history.c.saved_by, history.c.note)
                            .where(history.c.par_id == par_id).order_by(history.c.version)).all()
    return [{"version": r.version, "saved_at": r.saved_at, "saved_by": r.saved_by, "note": r.note} for r in rows]


@app.get("/api/pars/{par_id}/financials/versions/{version}")
def get_version(par_id: str, version: int):
    with engine.connect() as conn:
        row = conn.execute(select(history.c.body, history.c.saved_at).where((history.c.par_id == par_id) & (history.c.version == version))).first()
    if not row:
        raise HTTPException(404, f"version {version} not found")
    return {**row.body, "version": version, "saved_at": row.saved_at}


@app.post("/api/pars/{par_id}/financials/restore/{version}")
def restore_version(par_id: str, version: int, x_user: Optional[str] = Header(default=None)):
    """saves an old version again as the newest one (nothing is overwritten)"""
    old = get_version(par_id, version)
    doc = {k: v for k, v in old.items() if k not in ("version", "saved_at")}
    with engine.begin() as conn:
        cur = conn.execute(select(pars.c.version).where(pars.c.par_id == par_id)).scalar_one()
        saved_at = write_version(conn, par_id, doc, cur + 1, x_user or "anonymous", note=f"restored version {version}")
    return {"version": cur + 1, "saved_at": saved_at, **summary(doc)}


@app.get("/api/pars/{par_id}/financials/totals")
def totals(par_id: str):
    """computed totals for downstream consumers – derived, never stored"""
    return E.compute_totals(get_financials(par_id))


@app.get("/api/pars/{par_id}/financials/lines")
def financial_lines(par_id: str):
    """the flat reporting projection of the latest version"""
    with engine.connect() as conn:
        rows = conn.execute(select(lines).where(lines.c.par_id == par_id)).mappings().all()
    return [dict(r) for r in rows]


@app.post("/api/pars/{par_id}/financials/export")
def export(par_id: str, remove_empty_lines: bool = True, remove_empty_subcategories: bool = False,
           remove_empty_categories: bool = False):
    """server-side export (same layout as the export in the browser) – e.g. for the approval pack"""
    inst = get_financials(par_id)
    tpl = get_template(inst["template_id"], inst["template_version"])
    doc = {**tpl, "columns": inst["columns"], "nodes": inst["nodes"]}
    out = Path(tempfile.mkdtemp()) / f"PAR_Financial_{par_id}.xlsx"
    E.export_xlsx(doc, str(out), remove_empty_lines=remove_empty_lines,
                  remove_empty_subcategories=remove_empty_subcategories, remove_empty_categories=remove_empty_categories)
    return FileResponse(out, filename=out.name)
