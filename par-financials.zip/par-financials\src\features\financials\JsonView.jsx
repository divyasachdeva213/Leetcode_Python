import { useEffect, useState } from 'react';
import { api, usingMock } from '../../api/financialsApi';
import { toPayload } from '../../state/useFinancialDoc';

/** Shows exactly what is persisted and where it came from – useful while wiring the backend. */
export default function JsonView({ parId, doc, template, savedMeta, onReload, onLoadJson, onReset, onDownload }) {
  const [versions, setVersions] = useState([]);
  useEffect(() => { api.listVersions(parId).then(setVersions).catch(() => setVersions([])); }, [parId, savedMeta]);
  const tplSlim = { ...template, nodes: `[${template.nodes.length} top-level nodes …]` };
  return (
    <>
      <div className="flow">
        <span className="step">1 · GET template</span><span className="arr">→</span>
        <span className="step">2 · GET saved financials (or clone template)</span><span className="arr">→</span>
        <span className="step">3 · render tree + columns</span><span className="arr">→</span>
        <span className="step">4 · edits update JSON</span><span className="arr">→</span>
        <span className="step">5 · PUT (autosave)</span><span className="arr">→</span>
        <span className="step">6 · export from same JSON</span>
        <span className="grow" />
        <button className="btn sm" onClick={onReload}>⟳ Reload tab from saved</button>
        <button className="btn sm" onClick={onDownload}>Download JSON</button>
        <label className="btn sm">Load JSON
          <input type="file" accept=".json" hidden onChange={(e) => e.target.files[0] && onLoadJson(e.target.files[0])} /></label>
        <button className="btn sm" onClick={onReset}>Reset to template</button>
      </div>
      <div className="jsonview">
        <div className="jbox">
          <h4>What gets saved <code>PUT /api/pars/{parId}/financials</code></h4>
          <pre>{JSON.stringify(toPayload(parId, doc), null, 2)}</pre>
          <div className="vers">
            {versions.length
              ? `Versions: ${versions.map((v) => `v${v.version} (${new Date(v.saved_at).toLocaleTimeString()})`).join(' · ')}`
              : 'Nothing saved yet – press Save.'}
            {usingMock && ' · mock backend (localStorage)'}
          </div>
        </div>
        <div className="jbox">
          <h4>Template it was created from <code>GET /api/templates/{template.template_id}/versions/{template.template_version}</code></h4>
          <pre>{JSON.stringify(tplSlim, null, 2)}</pre>
        </div>
      </div>
    </>
  );
}
