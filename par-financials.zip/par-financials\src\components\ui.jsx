import { createContext, useCallback, useContext, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';

/* ── Modal ─────────────────────────────────────────────────────────────── */
export function Modal({ title, wide, onClose, footer, children }) {
  useEffect(() => {
    const k = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [onClose]);
  return createPortal(
    <div className="modal-bg" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className={`modal${wide ? ' wide' : ''}`} role="dialog" aria-label={title}>
        <h3>{title}</h3>
        <div className="body">{children}</div>
        {footer && <div className="foot">{footer}</div>}
      </div>
    </div>,
    document.body,
  );
}

/* ── Popover menu ──────────────────────────────────────────────────────────
   anchor: an element (opens below it) or a point {x, y} (right-click)
   items: [{label, onClick, check, hint, danger, disabled} | '-'] */
export function Menu({ anchor, items, onClose }) {
  const ref = useRef(null);
  const [pos, setPos] = useState({ left: -9999, top: -9999 });
  const isEl = typeof anchor?.getBoundingClientRect === 'function';
  useLayoutEffect(() => {
    const r = isEl ? anchor.getBoundingClientRect() : { left: anchor.x, top: anchor.y, bottom: anchor.y };
    const m = ref.current, mw = m.offsetWidth, mh = m.offsetHeight;
    setPos({
      left: Math.max(8, Math.min(r.left, window.innerWidth - mw - 8)),
      top: r.bottom + mh + 8 > window.innerHeight ? Math.max(8, r.top - mh - 4) : r.bottom + 4,
    });
  }, [anchor, isEl]);
  useEffect(() => {
    const down = (e) => { if (!ref.current?.contains(e.target) && !(isEl && anchor.contains(e.target))) onClose(); };
    const key = (e) => e.key === 'Escape' && onClose();
    const scroll = (e) => { if (!ref.current?.contains(e.target)) onClose(); };
    document.addEventListener('mousedown', down);
    document.addEventListener('keydown', key);
    window.addEventListener('scroll', scroll, true);
    return () => {
      document.removeEventListener('mousedown', down);
      document.removeEventListener('keydown', key);
      window.removeEventListener('scroll', scroll, true);
    };
  }, [anchor, isEl, onClose]);
  const onKeyDown = (e) => { // arrow keys move through the items
    if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp') return;
    e.preventDefault();
    const btns = [...ref.current.querySelectorAll('button:not(:disabled)')];
    btns[(btns.indexOf(document.activeElement) + (e.key === 'ArrowDown' ? 1 : -1) + btns.length) % btns.length]?.focus();
  };
  return createPortal(
    <div className="menu" ref={ref} style={pos} role="menu" onKeyDown={onKeyDown}>
      {items.map((it, i) =>
        it === '-' ? <hr key={i} /> : (
          <button key={i} role="menuitem" className={it.danger ? 'danger' : ''} disabled={it.disabled}
            onClick={() => { onClose(); it.onClick(); }}>
            <span className="chk">{it.check ? '✓' : ''}</span>
            <span className="ml">{it.label}</span>
            {it.hint && <kbd className="mk">{it.hint}</kbd>}
          </button>
        ))}
    </div>,
    document.body,
  );
}

/* ── Toasts + confirm dialog (context) ─────────────────────────────────── */
const UICtx = createContext(null);
export const useUI = () => useContext(UICtx);

export function UIProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const [confirmState, setConfirm] = useState(null);

  const toast = useCallback((msg) => {
    const id = Math.random();
    setToasts((t) => [...t, { id, msg }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2800);
  }, []);

  const confirm = useCallback((title, text, okLabel = 'Delete') =>
    new Promise((resolve) => setConfirm({ title, text, okLabel, resolve })), []);

  const close = (v) => { confirmState.resolve(v); setConfirm(null); };

  return (
    <UICtx.Provider value={{ toast, confirm }}>
      {children}
      {toasts.slice(-1).map((t) => <div key={t.id} className="toast" role="status">{t.msg}</div>)}
      {confirmState && (
        <Modal title={confirmState.title} onClose={() => close(false)}
          footer={<><button className="btn" onClick={() => close(false)}>Cancel</button>
            <button className="btn pri" onClick={() => close(true)}>{confirmState.okLabel}</button></>}>
          {confirmState.text}
        </Modal>
      )}
    </UICtx.Provider>
  );
}
