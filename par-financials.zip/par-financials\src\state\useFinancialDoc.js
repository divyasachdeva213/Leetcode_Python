/**
 * Document state for one PAR's financials:
 *   - loads template + saved instance, merges them
 *   - immutable updates with Immer (cheap snapshots → undo/redo)
 *   - dirty tracking + debounced autosave; every save says which version it started from,
 *     so a save made elsewhere in the meantime is reported (conflict) instead of overwritten
 */
import { useCallback, useEffect, useMemo, useReducer, useRef } from 'react';
import { produce } from 'immer';
import { api, ConflictError, DEFAULT_TEMPLATE } from '../api/financialsApi';

const MAX_HISTORY = 100;

/** what we persist – structure + values; instructions/config always come from the template */
export const toPayload = (parId, doc) => ({
  par_id: parId,
  template_id: doc.template_id,
  template_version: doc.template_version,
  schema_version: doc.schema_version,
  columns: doc.columns,
  nodes: doc.nodes,
});

/** instance = template (instructions, config) + saved structure/values */
export const mergeInstance = (template, saved) =>
  saved ? { ...template, columns: saved.columns, nodes: saved.nodes } : structuredClone(template);

const init = { status: 'idle', error: null, template: null, doc: null, loadedDoc: null, past: [], future: [], savedDoc: null, savedMeta: null,
  editBase: null, conflict: null, saveError: null };

function reducer(s, a) {
  switch (a.type) {
    case 'loading': return { ...init, status: 'loading' };
    case 'loaded': return { ...init, status: 'ready', template: a.template, doc: a.doc, loadedDoc: a.doc, savedDoc: a.saved ? a.doc : null, savedMeta: a.savedMeta };
    case 'error': return { ...s, status: 'error', error: a.error };
    case 'update': {
      // recipe mutates the draft; it may also return a whole new document (import / reset)
      const next = typeof a.recipe === 'function'
        ? produce(s.doc, (d) => { const r = a.recipe(d); if (r && typeof r === 'object' && Array.isArray(r.nodes)) return r; })
        : a.recipe;
      if (next === s.doc) return s;
      if (a.history === false) return { ...s, doc: next, editBase: s.editBase || s.doc };
      return { ...s, doc: next, past: [...s.past, s.editBase || s.doc].slice(-MAX_HISTORY), future: [], editBase: null };
    }
    case 'commitEdit': // end of a typing burst → one undo step
      if (!s.editBase || s.editBase === s.doc) return { ...s, editBase: null };
      return { ...s, past: [...s.past, s.editBase].slice(-MAX_HISTORY), future: [], editBase: null };
    case 'cancelEdit': // Esc: back to the value the cell had when editing started
      return s.editBase ? { ...s, doc: s.editBase, editBase: null } : s;
    case 'undo': {
      const past = s.editBase && s.editBase !== s.doc ? [...s.past, s.editBase] : s.past;
      if (!past.length) return s;
      const prev = past[past.length - 1];
      return { ...s, doc: prev, past: past.slice(0, -1), future: [s.doc, ...s.future], editBase: null };
    }
    case 'redo': {
      if (!s.future.length) return s;
      return { ...s, doc: s.future[0], past: [...s.past, s.doc], future: s.future.slice(1), editBase: null };
    }
    case 'saved': return { ...s, savedDoc: a.doc, savedMeta: a.meta, conflict: null, saveError: null };
    case 'conflict': return { ...s, conflict: a.info };
    case 'saveError': return { ...s, saveError: a.error };
    default: return s;
  }
}

export function useFinancialDoc(parId, { autosave = true, autosaveMs = 3000 } = {}) {
  const [s, dispatch] = useReducer(reducer, init);
  const saving = useRef(false);

  const load = useCallback(async () => {
    dispatch({ type: 'loading' });
    try {
      const saved = await api.getFinancials(parId);
      const tplId = saved?.template_id || DEFAULT_TEMPLATE.id;
      const tplVer = saved?.template_version || DEFAULT_TEMPLATE.version;
      const template = await api.getTemplate(tplId, tplVer);
      dispatch({ type: 'loaded', template, doc: mergeInstance(template, saved), saved: !!saved,
        savedMeta: saved ? { version: saved.version, saved_at: saved.saved_at } : null });
    } catch (e) {
      dispatch({ type: 'error', error: e.message });
    }
  }, [parId]);

  useEffect(() => { load(); }, [load]);

  const update = useCallback((recipe, opts = {}) => dispatch({ type: 'update', recipe, history: opts.history }), []);
  const commitEdit = useCallback(() => dispatch({ type: 'commitEdit' }), []);
  const cancelEdit = useCallback(() => dispatch({ type: 'cancelEdit' }), []);
  const undo = useCallback(() => dispatch({ type: 'undo' }), []);
  const redo = useCallback(() => dispatch({ type: 'redo' }), []);

  const dirty = useMemo(() => {
    if (!s.doc) return false;
    const base = s.savedDoc || s.loadedDoc; // a new PAR is only saved once someone changes something
    return s.doc.nodes !== base.nodes || s.doc.columns !== base.columns; // Immer keeps refs when unchanged
  }, [s.doc, s.savedDoc, s.loadedDoc]);

  /** overwrite: save on top of the version someone else saved (after a conflict) */
  const save = useCallback(async ({ overwrite = false } = {}) => {
    if (saving.current || !s.doc) return null;
    saving.current = true;
    const doc = s.doc;
    const base = overwrite && s.conflict ? s.conflict.current_version : s.savedMeta?.version ?? null;
    try {
      const meta = await api.saveFinancials(parId, { ...toPayload(parId, doc), base_version: base });
      dispatch({ type: 'saved', doc, meta });
      return meta;
    } catch (e) {
      if (e instanceof ConflictError) dispatch({ type: 'conflict', info: e.info });
      else dispatch({ type: 'saveError', error: e.message });
      return null;
    } finally {
      saving.current = false;
    }
  }, [parId, s.doc, s.savedMeta, s.conflict]);

  // debounced autosave (paused while a conflict is unresolved)
  useEffect(() => {
    if (!autosave || !dirty || s.status !== 'ready' || s.conflict) return undefined;
    const t = setTimeout(() => { save(); }, autosaveMs);
    return () => clearTimeout(t);
  }, [autosave, autosaveMs, dirty, s.doc, s.status, s.conflict, save]);

  return {
    status: s.status, error: s.error, template: s.template, doc: s.doc, savedMeta: s.savedMeta,
    conflict: s.conflict, saveError: s.saveError,
    dirty, canUndo: s.past.length > 0 || (!!s.editBase && s.editBase !== s.doc), canRedo: s.future.length > 0,
    update, commitEdit, cancelEdit, undo, redo, save, reload: load,
  };
}
