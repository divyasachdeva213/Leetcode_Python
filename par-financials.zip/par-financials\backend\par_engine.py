"""
PAR Financial – dynamic template engine (backend reference implementation).

One JSON document drives everything:
    template/metadata  ->  UI form  ->  preview  ->  Excel export  ->  (re)import

Document shape (see par_template_v3.json for a full example)
-----------------------------------------------------------
{
  "schema_version": "3.0",
  "template_id": "PAR_FINANCIAL_V3", "template_version": "3.0",
  "config":  {...fiscal year, currency...},
  "instructions": [{"id": ..., "text": ..., "kind": "rule"|"note"}],
  "columns": [ {id, label, type, role, aggregate, editable, width, group, hint, origin} ],
  "nodes":   [ <node>, ... ]            # top level = sections (or single-row items)
}
node (group) = {id, type:"group", label, definition, total:{show,label},
                exclude_from_parent_total, perms:{...}, origin, children:[node...]}
node (item)  = {id, type:"item", label, description, rules:{...}, perms:{...},
                origin, values:{column_id: value}}

Column types : text | date | amount | formula
Column roles : label | period | row_total | notes | definition | None
  * every `amount` column with role "period" is summed into the `row_total` column
  * every `amount` column with aggregate "sum" gets a subtotal on group total rows
Totals are NEVER stored – they are derived (compute_totals) or written as live
Excel formulas (export_xlsx), so any structural change keeps them correct.
"""
from __future__ import annotations

import copy
import datetime as _dt
import json
import re
import uuid
from typing import Any

# ─────────────────────────────────────────────────────────────── helpers ──

def _bool(v) -> bool:
    return str(v).strip().lower() in ("true", "1", "yes", "y")


def new_id(prefix: str = "N") -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8].upper()}"


def norm(s: Any) -> str:
    """normalise a label for fuzzy matching: 'FY4 ' == 'fy 4' == 'FY-4'"""
    return re.sub(r"[^a-z0-9]", "", str(s or "").lower())


def _words(s: str) -> set[str]:
    out = set()
    for w in re.findall(r"[a-z0-9]+", str(s).lower()):
        if w in ("total", "items", "item", "the", "and", "of", "other", "proposed", "project"):
            continue
        out.add(w[:-1] if w.endswith("s") and len(w) > 3 else w)
    return out


_MULT = {"k": 1e3, "m": 1e6, "mm": 1e6, "b": 1e9, "bn": 1e9}


def parse_number(v: Any):
    """Parse what people type or Excel puts on the clipboard: 1,234.50 | $1,234 | (500) | - | 12% | 15k | 1.2m
    (same rules as parseNumber in src/lib/parCore.js)"""
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return v if v == v and v not in (float("inf"), float("-inf")) else None
    s = re.sub("[−–—]", "-", str(v).strip())
    if s == "":
        return None
    if re.fullmatch(r"(\$\s*)?-", s):
        return 0
    neg = s.startswith("(") and s.endswith(")")
    s2 = re.sub(r"[()$€£,\s]|CAD|USD", "", s, flags=re.I)
    if s2.startswith("-"):
        neg, s2 = True, s2[1:]
    mult = 1
    m = re.fullmatch(r"(\d*\.?\d+)(k|mm|m|bn|b)", s2, flags=re.I)
    if m:
        s2, mult = m.group(1), _MULT[m.group(2).lower()]
    pct = mult == 1 and s2.endswith("%")
    s2 = s2.rstrip("%") if pct else s2
    if not re.fullmatch(r"\d+(\.\d+)?|\.\d+", s2):
        return None
    n = float(s2)
    if pct:
        n /= 100
    if mult != 1:
        n = round(n * mult, 2)
    n = -n if neg else n
    return int(n) if n.is_integer() else n


def is_rollup(n) -> bool:
    """group whose subtotal sits on its own row (an item broken down into sub-items, e.g. Hardware)"""
    return n.get("type") == "group" and (n.get("total") or {}).get("position") == "header"


def walk(nodes, depth=0, parent=None):
    """yield (node, depth, parent) depth-first"""
    for n in nodes:
        yield n, depth, parent
        if n["type"] == "group":
            yield from walk(n.get("children", []), depth + 1, n)


def find_node(doc, node_id):
    for n, d, p in walk(doc["nodes"]):
        if n["id"] == node_id:
            return n, d, p
    return None, None, None


# ────────────────────────────────────────────── 1. metadata -> template ──

TOTAL_LABELS = {  # labels used on the current PAR sheet
    "ASSETS": "Total",
    "NON_CASH_EXPENSES": "Total Non Cash Expenses",
    "PROJECT_BENEFITS": "Total Benefits",
    "PROPOSED_EXPENSES": "Total Proposed Project Expenses",
    "ONGOING_EXPENSES": "Total Ongoing Costs",
    "VARIABLE_COSTS": "Total Variable Costs",
    "ONE_TIME_COSTS": "Total One Time Costs",
    "COST_AVOIDANCE": "Total Cost Avoidance",
}


def _sheet_rows(ws):
    rows = list(ws.iter_rows(values_only=True))
    hdr = [str(h).strip() if h is not None else "" for h in rows[0]]
    return [dict(zip(hdr, r)) for r in rows[1:] if any(c is not None for c in r)]


def metadata_xlsx_to_template(path: str) -> dict:
    """Convert the v2 metadata workbook (categories/subcategories/items/columns)
    into the v3 recursive JSON template."""
    import openpyxl

    wb = openpyxl.load_workbook(path, data_only=True)
    cfg = {r["Setting"]: r["Value"] for r in _sheet_rows(wb["template_config"])}
    cats = sorted(_sheet_rows(wb["categories"]), key=lambda r: r["display_order"])
    subs = _sheet_rows(wb["subcategories"])
    items = _sheet_rows(wb["items"])
    cols_v2 = _sheet_rows(wb["columns"])
    rules = _sheet_rows(wb["business_rules"])

    def mk_item(r):
        rules_ = {}
        if _bool(r.get("must_have_notes")):
            rules_["must_have_notes"] = True
        if r.get("must_have_notes_if_over") not in (None, ""):
            rules_["must_have_notes_if_over"] = float(r["must_have_notes_if_over"])
        if _bool(r.get("must_specify_vendor")):
            rules_["must_specify_vendor"] = True
        if r.get("min_value") not in (None, ""):
            rules_["min_value"] = float(r["min_value"])
        return {
            "id": r["item_id"], "type": "item", "label": r["item_name"],
            "description": r.get("description") or "",
            "placeholder": r.get("placeholder") or "",
            "rules": rules_, "origin": "template",
            "perms": {"rename": True, "delete": True},
            "values": {},
        }

    nodes = []
    for c in cats:
        cid = c["category_id"]
        c_items = [mk_item(i) for i in items if i["parent_category_id"] == cid and not i.get("parent_subcategory_id")]
        c_subs = sorted([s for s in subs if s["parent_category_id"] == cid], key=lambda s: s["display_order"])
        # a category that is just one line (e.g. Provision for Credit Losses) -> top-level item
        if not c_subs and len(c_items) == 1 and not _bool(c["has_total_row"]):
            it = c_items[0]
            it.update(id=cid, label=c["category_name"], definition=c.get("description") or "")
            it["perms"] = {"rename": False, "delete": False}
            nodes.append(it)
            continue
        g = {
            "id": cid, "type": "group", "label": c["category_name"],
            "definition": c.get("description") or "",
            "total": {"show": _bool(c["has_total_row"]), "label": TOTAL_LABELS.get(cid, f"Total {c['category_name']}")},
            "exclude_from_parent_total": False,
            "ui": {"expanded": _bool(c.get("is_expanded_default", "true"))},
            "perms": {"rename": False, "delete": False,
                      "add_items": _bool(c["allow_add_items"]) or not c_subs,
                      "add_groups": _bool(c["allow_add_subcategories"]) or bool(c_subs)},
            "origin": "template", "children": c_items,
        }
        for s in c_subs:
            sid = s["subcategory_id"]
            g["children"].append({
                "id": sid, "type": "group", "label": s["subcategory_name"],
                "definition": s.get("description") or "",
                "total": {"show": _bool(s["has_total_row"]), "label": TOTAL_LABELS.get(sid, f"Total {s['subcategory_name']}")},
                # decision point for Finance: cost avoidance is not a spend
                "exclude_from_parent_total": sid == "COST_AVOIDANCE",
                "perms": {"rename": False, "delete": False, "add_items": _bool(s["allow_add_items"]), "add_groups": True},
                "origin": "template",
                "children": [mk_item(i) for i in items if i.get("parent_subcategory_id") == sid],
            })
        nodes.append(g)

    # columns: the PAR sheet is ONE grid, so take the union in display order
    seen, columns = set(), []
    for r in sorted(cols_v2, key=lambda r: r["display_order"]):
        if r["column_id"] in seen:
            continue
        seen.add(r["column_id"])
        cid, dt = r["column_id"], r["data_type"]
        col = {
            "id": cid, "label": r["column_name"], "width": r.get("width") or 14,
            "editable": _bool(r["is_editable"]), "visible": _bool(r["is_visible"]),
            "origin": "template", "group": None, "hint": None,
        }
        if cid == "item_name":
            col.update(type="text", role="label", aggregate="none")
        elif dt == "currency_formula":
            col.update(type="formula", role="row_total", aggregate="sum")
        elif re.fullmatch(r"fy\d+", cid):
            col.update(type="amount", role="period", aggregate="sum")
        elif dt == "currency":
            col.update(type="amount", role=None, aggregate="sum")
        elif dt == "date":
            col.update(type="date", role=None, aggregate="none")
        elif cid == "definition":
            col.update(type="text", role="definition", aggregate="none")
        elif cid == "notes":
            col.update(type="text", role="notes", aggregate="none")
        else:
            col.update(type="text", role=None, aggregate="none")
        columns.append(col)
    # things on the sheet that the v2 metadata did not have
    by_id = {c["id"]: c for c in columns}
    if "spend_to_date" in by_id:
        by_id["spend_to_date"]["hint"] = "As of : MMM/DD/YYYY"
    if "cost_incurred_by" in by_id:
        by_id["cost_incurred_by"].update(group="Cost Recovery", hint="e.g. GRM")
        columns.append({"id": "cost_recovered_from", "label": "Cost Being Recovered From", "type": "text",
                        "role": None, "aggregate": "none", "width": 20, "editable": True, "visible": True,
                        "origin": "template", "group": "Cost Recovery", "hint": "e.g. P&CB"})

    instr = [{"id": r["rule_id"], "text": r["rule_description"],
              "kind": "note" if r["rule_id"] == "finance_review" else "rule"} for r in rules]

    return {
        "schema_version": "3.0",
        "template_id": "PAR_FINANCIAL_V3",
        "template_version": "3.0",
        "template_name": cfg.get("template_name", "PAR Financial Template"),
        "config": {k: cfg[k] for k in ("fiscal_year_description", "currency", "include_taxes") if k in cfg},
        "instructions": instr,
        "columns": columns,
        "nodes": nodes,
    }


# ────────────────────────────────────────────────────────── 2. totals ──

def period_cols(doc):
    return [c for c in doc["columns"] if c.get("role") == "period"]


def sum_cols(doc):
    return [c for c in doc["columns"] if c["type"] == "amount" and c.get("aggregate") == "sum"]


def _num(v):
    n = parse_number(v)
    return n if isinstance(n, (int, float)) else 0


def item_row_total(doc, item):
    return sum(_num(item.get("values", {}).get(c["id"])) for c in period_cols(doc))


def group_sum(doc, group, col_id):
    tot = 0
    for ch in group.get("children", []):
        if ch["type"] == "item":
            tot += _num(ch.get("values", {}).get(col_id))
        elif not ch.get("exclude_from_parent_total"):
            tot += group_sum(doc, ch, col_id)
    return tot


def compute_totals(doc) -> dict:
    """{node_id: {col_id: value, 'total': row_total}} for every item and group"""
    out = {}
    rt = next((c["id"] for c in doc["columns"] if c.get("role") == "row_total"), None)
    for n, _, _ in walk(doc["nodes"]):
        if n["type"] == "item":
            row = {c["id"]: _num((n.get("values") or {}).get(c["id"])) for c in sum_cols(doc)}
        else:
            row = {c["id"]: group_sum(doc, n, c["id"]) for c in sum_cols(doc)}
        if rt:
            row[rt] = sum(row.get(c["id"], 0) for c in period_cols(doc))
        out[n["id"]] = row
    return out


def is_line(n) -> bool:
    """an item, or an item broken into sub-items (roll-up)"""
    return n.get("type") == "item" or is_rollup(n)


def has_data(doc, n) -> bool:
    """anything entered besides the label: a non-zero amount, unparsable text in an amount cell, notes, dates…"""
    v = n.get("values") or {}
    for c in doc["columns"]:
        if c.get("role") in ("label", "definition") or c["type"] == "formula":
            continue
        x = v.get(c["id"])
        if x is None or str(x).strip() == "":
            continue
        if c["type"] != "amount":
            return True
        p = parse_number(x)
        if p is None or p != 0:
            return True
    return False


def is_empty_node(doc, n) -> bool:
    return not has_data(doc, n) and (n["type"] == "item" or all(is_empty_node(doc, c) for c in n.get("children", [])))


def is_empty_line(doc, n) -> bool:
    return is_line(n) and is_empty_node(doc, n)


def prune_doc(doc, lines=True, subcategories=False, categories=False) -> dict:
    """copy without empty rows; by default only empty line items go (every header stays, like the form)"""
    d = {**doc, "nodes": copy.deepcopy(doc["nodes"])}

    def keep(n, depth):
        if depth == 0 and is_line(n):
            return not (categories and is_empty_line(d, n))
        if is_line(n):
            if lines and is_empty_line(d, n):
                return False
            if n["type"] == "group":
                n["children"] = [c for c in n["children"] if keep(c, depth + 1)]
            return True
        n["children"] = [c for c in n["children"] if keep(c, depth + 1)]
        if depth == 0:
            return not (categories and is_empty_node(d, n))
        return not (subcategories and is_empty_node(d, n))

    d["nodes"] = [n for n in d["nodes"] if keep(n, 0)]
    return d


_PLACEHOLDER = re.compile(r"^(?:new\s+line(?:\s+item)?|new\s+item|line(?:\s+item)?|item|revenue\s+item|cost\s+savings\s+item|"
                          r"incremental\s+savings\s+item|non-?cash\s+expense\s+item|\(unnamed\))\s*#?\s*\d*$", re.I)


def is_placeholder_label(label) -> bool:
    s = str(label or "").strip()
    return not s or bool(_PLACEHOLDER.match(s))


def _fmt(n) -> str:
    return "-" if abs(n) < 0.005 else (f"({abs(n):,.0f})" if n < 0 else f"{n:,.0f}")


def validate(doc) -> list[dict]:
    """business-rule warnings – the same rules and messages as validate() in src/lib/parCore.js"""
    notes_col = next((c["id"] for c in doc["columns"] if c.get("role") == "notes"), None)
    amounts = [c for c in doc["columns"] if c["type"] == "amount"]
    issues = []
    for n, _, _ in walk(doc["nodes"]):
        if n["type"] != "item":
            continue
        r, v = n.get("rules") or {}, n.get("values") or {}
        has_notes = bool(str(v.get(notes_col) or "").strip()) if notes_col else True
        tot = item_row_total(doc, n)
        msgs = []
        for c in amounts:
            raw = v.get(c["id"])
            if raw is not None and str(raw).strip() != "" and parse_number(raw) is None:
                msgs.append(f"{c['label']}: “{str(raw).strip()}” is not a number")
        if tot and not has_notes:
            if r.get("must_have_notes"):
                msgs.append("Add notes/assumptions for this line")
            if r.get("must_specify_vendor"):
                msgs.append("Name the external vendor in Notes/Assumptions")
            if r.get("must_have_notes_if_over") is not None and tot > r["must_have_notes_if_over"]:
                msgs.append(f"Add notes/assumptions: the total is above {_fmt(r['must_have_notes_if_over'])}")
        if r.get("min_value") is not None:
            for c in period_cols(doc):
                x = parse_number(v.get(c["id"]))
                if x is not None and x < r["min_value"]:
                    msgs.append(f"{c['label']} is negative" if r["min_value"] == 0 else f"{c['label']} is below {_fmt(r['min_value'])}")
        if is_placeholder_label(n.get("label")) and has_data(doc, n):
            msgs.append("Give this line a descriptive name")
        issues += [{"node": n["id"], "label": n.get("label"), "msg": m} for m in msgs]
    return issues


def project_lines(doc) -> list[dict]:
    """flat rows for reporting: one per entry line and amount column that holds a number (sub-items, not their roll-up row)"""
    amount_cols = [c for c in doc["columns"] if c["type"] == "amount"]
    out = []

    def rec(nodes, path, parent_id, depth):
        for n in nodes:
            p = path + [n.get("label") or ""]
            if n["type"] == "item":
                for c in amount_cols:
                    x = parse_number((n.get("values") or {}).get(c["id"]))
                    if x is not None:
                        out.append({"node_id": n["id"], "parent_id": parent_id, "path": " › ".join(p), "depth": depth,
                                    "label": n.get("label"), "column_id": c["id"], "column_label": c.get("label"), "amount": x})
            else:
                rec(n.get("children", []), p, n["id"], depth + 1)

    rec(doc["nodes"], [], None, 0)
    return out


# ─────────────────────────────────────── 3. smart paste / xlsx import ──

def _col_matchers(doc):
    m = {}
    for c in doc["columns"]:
        m[norm(c["label"])] = c["id"]
        m[norm(c["id"])] = c["id"]
    m[norm("Categories")] = next((c["id"] for c in doc["columns"] if c.get("role") == "label"), "item_name")
    return m


def _match_group(doc, label):
    """find a template group whose label/id fuzzily matches a pasted header row"""
    nl = norm(label.rstrip(":"))
    best, best_score = None, 0.0
    for n, d, p in walk(doc["nodes"]):
        if n["type"] != "group":
            continue
        cand = norm(n["label"])
        if nl == cand or nl == norm(n["id"]):
            return n, d, p
        a, b = _words(label), _words(n["label"])
        if a and b:
            score = len(a & b) / len(a | b)
            if score > best_score:
                best, best_score = (n, d, p), score
    return best if best_score >= 0.6 else (None, None, None)


def parse_table(doc: dict, rows: list[list[Any]], mode: str = "merge", create_columns: bool = True):
    """Turn a pasted Excel range (TSV rows) or a sheet's rows into the document.

    mode="merge"   : update matching items, append new ones, keep everything else
    mode="replace" : structure comes from the paste; template metadata (definitions,
                     perms, rules) is re-attached to groups/items it recognises
    Returns (new_doc, report)
    """
    doc = copy.deepcopy(doc)
    report = {"header_row": None, "mapped_columns": {}, "new_columns": [], "new_groups": [],
              "new_items": [], "updated_items": [], "total_rows": [], "warnings": []}
    rows = [list(r) for r in rows]
    colmap = _col_matchers(doc)

    # 1. header row = row with the most cells that match known columns
    best_i, best_hits = None, 1
    for i, r in enumerate(rows[:40]):
        hits = sum(1 for v in r if v is not None and norm(v) in colmap)
        if hits > best_hits:
            best_i, best_hits = i, hits
    label_col_id = next(c["id"] for c in doc["columns"] if c.get("role") == "label")
    idx_to_col: dict[int, str] = {}
    if best_i is not None:
        report["header_row"] = best_i
        hdr = rows[best_i]
        for j, v in enumerate(hdr):
            if v is None or str(v).strip() == "":
                continue
            cid = colmap.get(norm(v))
            if cid:
                idx_to_col[j] = cid
            elif create_columns:
                label = str(v).strip()
                is_period = bool(re.match(r"^(fy|q[1-4]|year|20\d\d|19\d\d)", label.strip(), re.I))
                data = [parse_number(r[j]) for r in rows[best_i + 1:] if j < len(r) and r[j] not in (None, "")]
                numeric = data and sum(x is not None for x in data) >= 0.6 * len(data)
                col = {"id": "col_" + norm(label)[:20] or new_id("COL"), "label": label,
                       "type": "amount" if (is_period or numeric) else "text",
                       "role": "period" if is_period else None,
                       "aggregate": "sum" if (is_period or numeric) else "none",
                       "editable": True, "visible": True, "width": 14, "origin": "user",
                       "group": None, "hint": None}
                # insert new period columns right after the last period column
                pos = len(doc["columns"])
                if is_period:
                    last = max((k for k, c in enumerate(doc["columns"]) if c.get("role") == "period"), default=pos - 1)
                    pos = last + 1
                doc["columns"].insert(pos, col)
                colmap[norm(label)] = col["id"]
                idx_to_col[j] = col["id"]
                report["new_columns"].append(label)
        body = rows[best_i + 1:]
    else:  # no header: assume template column order (skip computed columns)
        order = [c["id"] for c in doc["columns"] if c["type"] != "formula"]
        idx_to_col = {j: cid for j, cid in enumerate(order)}
        body = rows
    report["mapped_columns"] = {str(k): v for k, v in idx_to_col.items()}
    label_idx = next((j for j, c in idx_to_col.items() if c == label_col_id), 0)
    cols_by_id = {c["id"]: c for c in doc["columns"]}

    template_doc = copy.deepcopy(doc)
    if mode == "replace":
        doc["nodes"] = []

    def clone_group(tg):
        g = {k: copy.deepcopy(v) for k, v in tg.items() if k != "children"}
        g["children"] = []
        g["total"] = dict(g.get("total", {}), show=False)  # will be switched on if a total row is seen
        return g

    stack: list[dict] = []      # open groups (in the target doc)
    used_items: set[str] = set()

    def container():
        return stack[-1]["children"] if stack else doc["nodes"]

    def locate(target_id):
        n, _, _ = find_node(doc, target_id)
        return n

    for r in body:
        cells = {cid: (r[j] if j < len(r) else None) for j, cid in idx_to_col.items()}
        raw_label = r[label_idx] if label_idx < len(r) else None
        label = str(raw_label).strip() if raw_label is not None else ""
        vals, has_number, has_text = {}, False, False
        for cid, v in cells.items():
            c = cols_by_id[cid]
            if cid == label_col_id or c["type"] == "formula" or c.get("role") == "definition":
                continue
            if v is None or str(v).strip() == "":
                continue
            if c["type"] == "amount":
                n = parse_number(v)
                if n is not None:
                    vals[cid], has_number = n, True
            elif c["type"] == "date":
                vals[cid] = v.strftime("%d/%m") if isinstance(v, (_dt.date, _dt.datetime)) else str(v).strip()
                has_text = True
            else:
                vals[cid] = str(v).strip()
                has_text = True
        definition = next((str(cells[c]).strip() for c in cells
                           if cols_by_id[c].get("role") == "definition" and cells[c]), "")
        if not label and not any((isinstance(v, (int, float)) and v != 0) or isinstance(v, str) for v in vals.values()):
            continue  # blank / zero-only spacer rows

        # ── total row: switch totals on for the matching open group, never store numbers
        if norm(label).startswith("total"):
            if not stack:
                report["warnings"].append(f"'{label}' has no open section – ignored")
                continue
            tw = _words(label)
            pick = max(range(len(stack)), key=lambda k: (len(tw & _words(stack[k]["label"])), k)) if tw else len(stack) - 1
            g = stack[pick]
            g["total"] = {"show": True, "label": label}
            report["total_rows"].append(label)
            del stack[pick:]
            continue

        tg, tdepth, tparent = _match_group(template_doc, label) if label else (None, None, None)
        top_item = None
        if label and not tg:
            top_item = next((n for n in template_doc["nodes"] if n["type"] == "item" and
                             (norm(n["label"]) == norm(label) or norm(n["id"]) == norm(label))), None)

        exact = tg is not None and norm(label.rstrip(":")) in (norm(tg["label"]), norm(tg["id"]))
        has_nonzero = any(isinstance(v, (int, float)) and v != 0 for v in vals.values())
        is_group = (tg is not None and ((exact and is_rollup(tg)) or (not has_nonzero if exact else not has_number))) or \
                   (label.endswith(":") and not top_item) or \
                   (not has_number and not has_text and label and not top_item)

        if is_group:
            if tg is not None:
                if mode == "merge":
                    g = locate(tg["id"])
                    if g is None:  # was deleted by the user – re-add under its parent
                        g = clone_group(tg)
                        container().append(g)
                    stack[:] = _path_to(doc, g["id"])  # re-open the group where it lives
                else:
                    g = clone_group(tg)
                    if tdepth == 0:
                        stack.clear()
                    else:
                        del stack[tdepth:]  # stay inside current section
                    container().append(g)
                    stack.append(g)
                if definition:
                    g["definition"] = definition
            else:
                g = {"id": new_id("GRP"), "type": "group", "label": label.rstrip(":").strip(),
                     "definition": definition, "total": {"show": False, "label": f"Total {label.rstrip(':').strip()}"},
                     "exclude_from_parent_total": False, "origin": "user",
                     "perms": {"rename": True, "delete": True, "add_items": True, "add_groups": True},
                     "children": []}
                # 'Xyz Items:' style header inside a section = subsection; otherwise a new section
                if not (label.endswith(":") and stack):
                    stack.clear()
                else:
                    del stack[1:]
                container().append(g)
                stack.append(g)
                report["new_groups"].append(g["label"])
            continue

        # ── item row
        if top_item is not None:
            stack.clear()
            existing = locate(top_item["id"])
            if existing is None:
                existing = copy.deepcopy(top_item)
                existing["values"] = {}
                doc["nodes"].append(existing)
            existing["values"].update(vals)
            report["updated_items"].append(existing["label"])
            continue
        # a roll-up row only owns rows that match its children
        while stack and is_rollup(stack[-1]) and not any(norm(c["label"]) == norm(label) for c in stack[-1]["children"]):
            stack.pop()
        siblings = container()
        match = next((s for s in siblings if s["type"] == "item" and s["id"] not in used_items
                      and norm(s["label"]) == norm(label)), None)
        if match:
            if mode == "replace":
                match["values"] = {}
            match["values"].update(vals)
            used_items.add(match["id"])
            report["updated_items"].append(label)
        else:
            # re-attach template metadata (rules/description) when the label is known
            tmpl = next((n for n, _, _ in walk(template_doc["nodes"])
                         if n["type"] == "item" and norm(n["label"]) == norm(label)
                         and (not stack or _in_group(template_doc, n["id"], stack[-1]["id"]))), None)
            it = copy.deepcopy(tmpl) if tmpl else {
                "id": new_id("ITM"), "type": "item", "label": label or "(unnamed)", "description": "",
                "rules": {}, "origin": "user", "perms": {"rename": True, "delete": True}, "values": {}}
            it["values"] = vals
            siblings.append(it)
            used_items.add(it["id"])
            report["new_items"].append(it["label"])

    # cross-check pasted totals against recomputed ones would go here (report only)
    return doc, report


def _path_to(doc, node_id):
    def rec(nodes, path):
        for n in nodes:
            if n["id"] == node_id:
                return path + [n]
            if n["type"] == "group":
                got = rec(n["children"], path + [n])
                if got:
                    return got
        return None
    return rec(doc["nodes"], []) or []


def _in_group(doc, item_id, group_id):
    return any(n["id"] == group_id for n in _path_to(doc, item_id)[:-1])


def import_par_xlsx(doc_template: dict, path: str, mode: str = "replace"):
    """Read a filled PAR sheet (any version produced by us or by hand)."""
    import openpyxl
    wb = openpyxl.load_workbook(path, data_only=False)
    ws = wb.worksheets[0]
    rows = [list(r) for r in ws.iter_rows(values_only=True)]
    # formula strings (e.g. '=SUM(F16:J16)') are totals – drop them
    rows = [[None if isinstance(v, str) and v.startswith("=") else v for v in r] for r in rows]
    return parse_table(doc_template, rows, mode=mode)


def parse_tsv(text: str) -> list[list[str]]:
    """clipboard text/plain from Excel -> rows (handles quoted multi-line cells)"""
    rows, row, cell, q, i = [], [], "", False, 0
    while i < len(text):
        ch = text[i]
        if q:
            if ch == '"' and i + 1 < len(text) and text[i + 1] == '"':
                cell += '"'; i += 1
            elif ch == '"':
                q = False
            else:
                cell += ch
        elif ch == '"' and cell == "":
            q = True
        elif ch == "\t":
            row.append(cell); cell = ""
        elif ch in "\r\n":
            if ch == "\r" and i + 1 < len(text) and text[i + 1] == "\n":
                i += 1
            row.append(cell); rows.append(row); row, cell = [], ""
        else:
            cell += ch
        i += 1
    if cell or row:
        row.append(cell); rows.append(row)
    return rows


# ───────────────────────────────────────────────────── 4. xlsx export ──

def export_xlsx(doc: dict, path: str):
    """Write the document in the PAR Financial sheet layout with live formulas."""
    import openpyxl
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter as L

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "PAR Financial Template"
    ws.sheet_view.showGridLines = False
    ACC = '_(* #,##0_);_(* \\(#,##0\\);_(* "-"_);_(@_)'
    thin, med = Side(style="thin"), Side(style="medium")
    grey = PatternFill("solid", fgColor="F2F2F2")
    hdr_fill = PatternFill("solid", fgColor="D9E1F2")
    sec_fill = PatternFill("solid", fgColor="EDEDED")
    bold = Font(bold=True)

    cols = [c for c in doc["columns"] if c.get("visible", True)]
    first_col = 2  # column B, like the original sheet
    letter = {c["id"]: L(first_col + k) for k, c in enumerate(cols)}
    period = [c["id"] for c in cols if c.get("role") == "period"]
    sumcols = [c["id"] for c in cols if c["type"] == "amount" and c.get("aggregate") == "sum"]
    rt_id = next((c["id"] for c in cols if c.get("role") == "row_total"), None)
    label_id = next(c["id"] for c in cols if c.get("role") == "label")
    def_id = next((c["id"] for c in cols if c.get("role") == "definition"), None)
    last = L(first_col + len(cols) - 1)

    def rng(col_letter, rows_):
        """compress [16,17,18,25] -> 'F16:F18,F25'"""
        rows_ = sorted(rows_)
        parts, start, prev = [], None, None
        for r in rows_:
            if start is None:
                start = prev = r
            elif r == prev + 1:
                prev = r
            else:
                parts.append((start, prev)); start = prev = r
        if start is not None:
            parts.append((start, prev))
        return ",".join(f"{col_letter}{a}" if a == b else f"{col_letter}{a}:{col_letter}{b}" for a, b in parts)

    def row_total_formula(r):
        if not period:
            return 0
        idx = sorted(cols.index(next(c for c in cols if c["id"] == p)) for p in period)
        contiguous = idx == list(range(idx[0], idx[0] + len(idx)))
        if contiguous:
            return f"=SUM({letter[period[0]]}{r}:{letter[period[-1]]}{r})"
        return "=SUM(" + ",".join(f"{letter[p]}{r}" for p in period) + ")"

    # instructions
    r = 2
    ws.cell(r, first_col, "Instructions:").font = bold
    for ins in [i for i in doc.get("instructions", []) if i.get("kind") != "note"]:
        r += 1
        ws.cell(r, first_col, ins["text"])
    for ins in [i for i in doc.get("instructions", []) if i.get("kind") == "note"]:
        r += 2
        ws.cell(r, first_col, "Note: " + ins["text"]).font = Font(bold=True, italic=True)
    r += 2

    # column-group row (e.g. "Cost Recovery") + header row
    groups = {}
    for c in cols:
        if c.get("group"):
            groups.setdefault(c["group"], []).append(letter[c["id"]])
    for gname, ls in groups.items():
        ws.cell(r, openpyxl.utils.column_index_from_string(ls[0]), gname)
        if len(ls) > 1:
            ws.merge_cells(f"{ls[0]}{r}:{ls[-1]}{r}")
        for l in ls:
            cc = ws[f"{l}{r}"]
            cc.font, cc.alignment = bold, Alignment(horizontal="center")
            cc.border, cc.fill = Border(top=thin, left=thin, right=thin), hdr_fill
    r += 1
    header_row = r
    for c in cols:
        cc = ws[f"{letter[c['id']]}{r}"]
        cc.value = c["label"]
        cc.font, cc.fill = bold, hdr_fill
        cc.alignment = Alignment(wrap_text=True, vertical="center", horizontal="left" if c["type"] == "text" else "center")
        cc.border = Border(top=med, bottom=med, left=thin, right=thin)
        ws.column_dimensions[letter[c["id"]]].width = c.get("width") or 14
    ws.column_dimensions["A"].width = 3.4
    ws.column_dimensions[letter[label_id]].width = max(ws.column_dimensions[letter[label_id]].width, 44)
    ws.freeze_panes = ws.cell(header_row + 1, first_col + 1)
    r += 1

    box = Border(top=thin, bottom=thin, left=thin, right=thin)

    def style_row(row, fill=None, font=None, top=None):
        for c in cols:
            cc = ws[f"{letter[c['id']]}{row}"]
            cc.border = Border(top=top or thin, bottom=thin, left=thin, right=thin)
            if fill:
                cc.fill = fill
            if font:
                cc.font = font
            if c["type"] in ("amount", "formula"):
                cc.number_format = ACC
            if c.get("role") in ("definition", "notes"):
                cc.alignment = Alignment(wrap_text=True, vertical="top")
        if rt_id:
            ws[f"{letter[rt_id]}{row}"].fill = fill or grey

    first_group_header = [True]

    def emit(node, depth):
        nonlocal r
        if node["type"] == "item":
            row = r
            ws[f"{letter[label_id]}{row}"] = node["label"]
            for c in cols:
                if c["id"] == label_id or c["type"] == "formula":
                    continue
                v = node.get("values", {}).get(c["id"])
                if c["type"] == "amount":
                    v = parse_number(v)
                    v = 0 if v is None and c["id"] in period else v
                if v not in (None, ""):
                    ws[f"{letter[c['id']]}{row}"] = v
            if def_id and depth == 0 and node.get("definition"):
                ws[f"{letter[def_id]}{row}"] = node["definition"]
            if rt_id:
                ws[f"{letter[rt_id]}{row}"] = row_total_formula(row)
            style_row(row, font=bold if depth == 0 else None)
            ws[f"{letter[label_id]}{row}"].alignment = Alignment(indent=max(depth - 1, 0) if depth else 0)
            r += 1
            return {"row": row}
        # group header row
        hdr = r
        rollup = is_rollup(node)
        ws[f"{letter[label_id]}{hdr}"] = node["label"] if rollup else node["label"] + (":" if depth > 0 and not node["label"].endswith(":") else "")
        if def_id and node.get("definition"):
            ws[f"{letter[def_id]}{hdr}"] = node["definition"]
        if first_group_header[0]:
            for c in cols:
                if c.get("hint"):
                    ws[f"{letter[c['id']]}{hdr}"] = c["hint"]
            first_group_header[0] = False
        if rollup:
            for c in cols:
                v = node.get("values", {}).get(c["id"])
                if c["type"] not in ("amount", "formula") and c["id"] != label_id and c.get("role") != "definition" and v not in (None, ""):
                    ws[f"{letter[c['id']]}{hdr}"] = v
            style_row(hdr, fill=sec_fill if depth == 0 else None, font=bold, top=med if depth == 0 else thin)
            ws[f"{letter[label_id]}{hdr}"].alignment = Alignment(indent=max(depth - 1, 0))
        else:
            style_row(hdr, fill=sec_fill if depth == 0 else None, font=bold if depth == 0 else Font(bold=True, italic=True),
                      top=med if depth == 0 else thin)
            ws[f"{letter[label_id]}{hdr}"].alignment = Alignment(indent=depth)
        r += 1
        term_rows = []  # rows whose values roll up into this group's total
        for ch in node.get("children", []):
            res = emit(ch, depth + 1)
            if ch["type"] == "group" and ch.get("exclude_from_parent_total"):
                continue
            term_rows += [res["row"]] if res.get("row") else res.get("terms", [])
        out = {"terms": term_rows}
        if rollup:  # subtotal on the item's own row
            for cid in sumcols:
                ws[f"{letter[cid]}{hdr}"] = f"=SUM({rng(letter[cid], term_rows)})" if term_rows else 0
            if rt_id:
                ws[f"{letter[rt_id]}{hdr}"] = row_total_formula(hdr)
            return {"row": hdr}
        if node.get("total", {}).get("show"):
            tr = r
            ws[f"{letter[label_id]}{tr}"] = node["total"].get("label") or f"Total {node['label']}"
            for cid in sumcols:
                ws[f"{letter[cid]}{tr}"] = f"=SUM({rng(letter[cid], term_rows)})" if term_rows else 0
            if rt_id:
                ws[f"{letter[rt_id]}{tr}"] = row_total_formula(tr)
            style_row(tr, fill=grey, font=bold, top=thin)
            for c in cols:  # double-ish emphasis
                ws[f"{letter[c['id']]}{tr}"].border = Border(top=thin, bottom=med if depth == 0 else thin, left=thin, right=thin)
            r += 1
            out = {"row": tr}
        return out

    for n in doc["nodes"]:
        emit(n, 0)
        r += 1  # blank spacer between sections
    ws.print_title_rows = f"{header_row}:{header_row}"
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    wb.save(path)
    return path


# ────────────────────────────────────────────── 5. v3 metadata workbook ──

def template_to_metadata_xlsx(doc: dict, path: str):
    """Flat, table-friendly storage of the recursive template (one row per node).
    Same shape maps 1:1 to DB tables: template_columns, template_nodes."""
    import openpyxl
    from openpyxl.styles import Font
    wb = openpyxl.Workbook()
    ws = wb.active; ws.title = "template_config"
    ws.append(["Setting", "Value"])
    for k in ("template_id", "template_version", "template_name", "schema_version"):
        ws.append([k, doc.get(k)])
    for k, v in doc.get("config", {}).items():
        ws.append([k, v])

    ws = wb.create_sheet("columns")
    hdr = ["column_id", "label", "display_order", "type", "role", "aggregate", "editable", "visible", "width", "group", "hint", "origin"]
    ws.append(hdr)
    for k, c in enumerate(doc["columns"], 1):
        ws.append([c["id"], c["label"], k, c["type"], c.get("role"), c.get("aggregate"), c.get("editable"),
                   c.get("visible", True), c.get("width"), c.get("group"), c.get("hint"), c.get("origin")])

    ws = wb.create_sheet("nodes")
    hdr = ["node_id", "parent_id", "node_type", "depth", "display_order", "label", "definition", "description",
           "show_total", "total_label", "subtotal_position", "exclude_from_parent_total", "allow_add_items", "allow_add_groups",
           "allow_rename", "allow_delete", "must_have_notes", "must_have_notes_if_over", "must_specify_vendor", "origin"]
    ws.append(hdr)
    order: dict[str, int] = {}
    for n, d, p in walk(doc["nodes"]):
        key = p["id"] if p else "__root__"
        order[key] = order.get(key, 0) + 1
        perms, rules = n.get("perms", {}), n.get("rules", {})
        ws.append([n["id"], p["id"] if p else None, n["type"], d, order[key], n["label"], n.get("definition"),
                   n.get("description"), n.get("total", {}).get("show") if n["type"] == "group" else None,
                   n.get("total", {}).get("label") if n["type"] == "group" else None,
                   (n.get("total", {}).get("position") or "footer") if n["type"] == "group" else None,
                   n.get("exclude_from_parent_total"), perms.get("add_items"), perms.get("add_groups"),
                   perms.get("rename"), perms.get("delete"), rules.get("must_have_notes"),
                   rules.get("must_have_notes_if_over"), rules.get("must_specify_vendor"), n.get("origin")])

    ws = wb.create_sheet("instructions")
    ws.append(["rule_id", "kind", "text"])
    for i in doc.get("instructions", []):
        ws.append([i["id"], i.get("kind"), i["text"]])
    for s in wb.worksheets:
        for c in s[1]:
            c.font = Font(bold=True)
        for col in s.columns:
            s.column_dimensions[col[0].column_letter].width = min(60, max(12, max(len(str(x.value or "")) for x in col) + 2))
    wb.save(path)


if __name__ == "__main__":
    import sys
    tpl = metadata_xlsx_to_template(sys.argv[1])
    print(json.dumps(tpl, indent=2)[:2000])
