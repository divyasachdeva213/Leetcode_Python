import { useState } from 'react';
import * as P from '../../lib/parCore';
import { setCell } from '../../lib/docOps';

// a cell reached with the keyboard (Tab, Enter, arrows) selects its content so typing replaces it, like Excel;
// a click places the caret
let pointerAt = 0;
if (typeof document !== 'undefined') document.addEventListener('pointerdown', () => { pointerAt = Date.now(); }, true);
const selectIfKeyboard = (e) => { if (Date.now() - pointerAt > 300) e.target.select(); };

/** text / date / label cell. Typing updates the doc live (no undo step per key); blur = one undo step, Esc (grid) = revert */
export function TextCell({ node, col, value, update, commitEdit, readOnly, autoFocus, title, placeholder, ariaLabel }) {
  return (
    <input
      className="cell"
      data-id={node.id}
      data-col={col.id}
      value={value ?? ''}
      readOnly={readOnly}
      autoFocus={autoFocus}
      onFocus={autoFocus ? (e) => e.target.select() : selectIfKeyboard}
      title={title}
      placeholder={placeholder}
      aria-label={ariaLabel || col.label}
      onChange={(e) => update((d) => setCell(d, node.id, col.id, e.target.value), { history: false })}
      onBlur={commitEdit}
    />
  );
}

/** amount cell: raw while editing (accepts 1,234 / (500) / -500 / 15k), accounting format otherwise */
export function AmountCell({ node, col, update, commitEdit }) {
  const stored = node.values?.[col.id];
  const [draft, setDraft] = useState(null); // string while focused
  const parsed = P.parseNumber(stored);
  const bad = stored != null && stored !== '' && parsed == null;
  const shown = draft != null ? draft : bad ? String(stored) : P.fmt(parsed);
  return (
    <input
      className={`cell num${bad ? ' bad' : ''}${parsed < 0 ? ' neg' : ''}`}
      inputMode="decimal"
      data-id={node.id}
      data-col={col.id}
      value={shown}
      aria-label={`${node.label} – ${col.label}`}
      title={bad ? 'Not a number – use digits like 1,234 or (500) or 15k' : undefined}
      onFocus={(e) => { setDraft(stored == null ? '' : String(stored)); requestAnimationFrame(() => e.target.select()); }}
      onChange={(e) => { setDraft(e.target.value); update((d) => setCell(d, node.id, col.id, e.target.value), { history: false }); }}
      onBlur={() => { setDraft(null); commitEdit(); }}
    />
  );
}
