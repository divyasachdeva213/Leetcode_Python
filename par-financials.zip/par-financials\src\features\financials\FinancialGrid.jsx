import { useMemo, useState } from 'react';
import * as P from '../../lib/parCore';
import * as Ops from '../../lib/docOps';
import { AmountCell, TextCell } from './cells';

export const colWidth = (c) => {
  if (c.role === 'label') return 350;
  if (c.role === 'definition') return 260;
  if (c.role === 'notes') return 230;
  if (c.role === 'row_total') return 112;
  if (c.type === 'date') return 96;
  if (c.type === 'amount') return 106;
  return Math.max(130, Math.round((c.width || 14) * 7));
};
/** Compact = label, Total, the period (FY) columns and notes; screen only, the export always has every column */
export const gridColumns = (doc, compact) =>
  P.cols(doc).filter((c) => !compact || ['label', 'row_total', 'period', 'notes'].includes(c.role));

const summed = (c) => c.type === 'formula' || (c.type === 'amount' && c.aggregate === 'sum');
const canDrag = (n) => n.perms?.delete !== false; // standard categories of the form stay where they are
const blankZero = (v) => (v ? P.fmt(v) : ''); // empty lines and subtotals stay blank instead of "-"

/**
 * The editable grid: the PAR form, made interactive. Rows come from P.buildRows(doc).
 * Paste works on any cell, including the empty cells of category rows and "+ Add line item" rows.
 * Right-click a row for its menu; Ctrl+Enter in a line adds a line below it.
 */
export default function FinancialGrid({
  doc, totals, issues, collapsed, focusId, hideEmpty, compact,
  update, commitEdit, cancelEdit, onToggle, onNodeMenu, onAddMenu, onColMenu,
  onAddItem, onAddSub, onAddSection, onAddTopItem, onAddColumn, onPaste, onBreakDown, onMove, onInsertBelow,
}) {
  const C = gridColumns(doc, compact);
  const rows = useMemo(() => P.buildRows(doc, { edit: true, collapsed, hideEmpty }), [doc, collapsed, hideEmpty]);
  const emptyLines = useMemo(() => new Set([...P.walk(doc.nodes)].filter(([n]) => P.isEmptyLine(doc, n)).map(([n]) => n.id)), [doc]);
  const [drag, setDrag] = useState(null); // { id, over: { key, pos, parentId, index } }
  const width = C.reduce((a, c) => a + colWidth(c), 44);

  const groupSpans = [];
  for (let i = 0; i < C.length;) {
    const g = C[i].group;
    let span = 1;
    while (g && C[i + span]?.group === g) span++;
    groupSpans.push({ g, span, first: i === 0 });
    i += span;
  }

  const onKeyDown = (e) => {
    const t = e.target;
    const row = t.closest?.('tr[data-row]');
    if (e.key === 'ContextMenu' || (e.shiftKey && e.key === 'F10')) { // the row's menu from the keyboard
      if (row) { e.preventDefault(); const r = row.getBoundingClientRect(); onNodeMenu({ x: r.left + 40, y: r.bottom }, row.dataset.row); }
      return;
    }
    if (!t.matches('input.cell')) return;
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); commitEdit(); onInsertBelow(row?.dataset.row); return; }
    if (e.key === 'Escape') { e.preventDefault(); cancelEdit(); t.blur(); return; }
    if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
      const left = e.key === 'ArrowLeft';
      const atEdge = left ? t.selectionStart === 0 && t.selectionEnd === 0 : t.selectionStart === t.value.length && t.selectionEnd === t.value.length;
      if (!atEdge) return;
      const cells = [...t.closest('tr').querySelectorAll('input.cell')];
      const next = cells[cells.indexOf(t) + (left ? -1 : 1)];
      if (next) { e.preventDefault(); next.focus(); }
      return;
    }
    const down = (e.key === 'Enter' && !e.shiftKey) || e.key === 'ArrowDown';
    const up = (e.key === 'Enter' && e.shiftKey) || e.key === 'ArrowUp';
    if (!down && !up) return;
    e.preventDefault();
    const all = [...e.currentTarget.querySelectorAll(`input.cell[data-col="${t.dataset.col}"]`)];
    all[all.indexOf(t) + (down ? 1 : -1)]?.focus();
  };

  // ── drag and drop, right-click
  const target = (r, e) => {
    const n = r.node;
    if ((r.kind === 'group' && !r.rollup) || r.kind === 'add' || r.kind === 'total')
      return { key: `${r.kind}-${n.id}`, pos: 'inside', parentId: n.id, index: n.children.length };
    if (r.kind === 'item' || r.kind === 'group') {
      const rect = e.currentTarget.getBoundingClientRect(), before = e.clientY - rect.top < rect.height / 2;
      const sibs = r.parent ? r.parent.children : doc.nodes;
      return { key: `${r.kind}-${n.id}`, pos: before ? 'before' : 'after', parentId: r.parent?.id ?? null, index: sibs.indexOf(n) + (before ? 0 : 1) };
    }
    return null;
  };
  const dnd = (r) => ({
    onContextMenu: (e) => {
      if (window.getSelection()?.toString()) return; // keep the browser's menu for copying selected text
      e.preventDefault();
      onNodeMenu({ x: e.clientX, y: e.clientY }, r.node.id); // add and total rows open their category's menu
    },
    onDragOver: (e) => {
      if (!drag) return;
      const t = target(r, e);
      if (!t || r.node.id === drag.id || !Ops.canMoveTo(doc, drag.id, t.parentId)) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      if (drag.over?.key !== t.key || drag.over?.pos !== t.pos) setDrag({ ...drag, over: t });
    },
    onDrop: (e) => {
      if (!drag?.over) return;
      e.preventDefault();
      onMove(drag.id, drag.over.parentId, drag.over.index);
      setDrag(null);
    },
  });
  const dropCls = (r) => (drag?.over?.key === `${r.kind}-${r.node.id}` ? ` drop-${drag.over.pos}` : '');
  const grip = (n) => canDrag(n) && (
    <span className="grip" draggable title="Drag to move"
      onDragStart={(e) => { e.dataTransfer.setData('text/plain', n.id); e.dataTransfer.effectAllowed = 'move'; setDrag({ id: n.id, over: null }); }}
      onDragEnd={() => setDrag(null)}>⋮⋮</span>
  );
  const ctx = { C, update, commitEdit, onToggle, onNodeMenu, onAddMenu, onAddItem, onAddSub, onBreakDown, grip, dnd, dropCls, emptyLines };

  return (
    <div className={`gridwrap${drag ? ' dragging' : ''}`} onKeyDown={onKeyDown} onPaste={onPaste}>
      {/* --lw: the Total column sticks next to the label column while scrolling across many years */}
      <table className="grid" style={{ width, '--lw': `${colWidth(C[0])}px` }}>
        <colgroup>
          {C.map((c) => <col key={c.id} style={{ width: colWidth(c) }} />)}
          <col style={{ width: 44 }} />
        </colgroup>
        <thead>
          {groupSpans.some((s) => s.g) && (
            <tr className="cg">
              {groupSpans.map((s, i) => <th key={i} colSpan={s.span} className={s.first ? 'stick' : ''}>{s.g || ''}</th>)}
              <th />
            </tr>
          )}
          <tr>
            {C.map((c) => (
              <th key={c.id} className={`${c.role === 'label' ? 'stick' : ''}${c.role === 'row_total' ? ' rt' : ''}`}>
                <div className="th">
                  <span className="lbl">{c.label}</span>
                  {c.role === 'period' && <span className="tag" title="Included in the row Total">Σ</span>}
                  {c.type === 'formula' && <span className="tag calc" title="Calculated">fx</span>}
                  {c.origin === 'user' && c.role !== 'period' && <span className="tag user">custom</span>}
                  {c.role !== 'label' && <button className="ico" title="Column options" onClick={(e) => onColMenu(e.currentTarget, c.id)}>⋯</button>}
                </div>
              </th>
            ))}
            <th className="addcol"><button className="ico" title="Add column" onClick={onAddColumn}>＋</button></th>
          </tr>
        </thead>
        <tbody>
          {!rows.length && (
            <tr><td colSpan={C.length + 1}><div className="empty">No categories yet. Use ＋ Add above, or import an Excel file.</div></td></tr>
          )}
          {rows.map((r) => {
            const n = r.node;
            if (r.kind === 'spacer') return <tr key={r.key} className="gap"><td colSpan={C.length + 1} /></tr>;
            if (r.kind === 'group' && r.rollup) return <RollupRow key={n.id} r={r} T={totals[n.id]} collapsed={collapsed.has(n.id)} autoFocus={focusId === n.id} {...ctx} />;
            if (r.kind === 'group') return <GroupRow key={n.id} r={r} T={totals[n.id]} collapsed={collapsed.has(n.id)} autoFocus={focusId === n.id} {...ctx} />;
            if (r.kind === 'item') return <ItemRow key={n.id} r={r} T={totals[n.id]} issues={issues[n.id]} autoFocus={focusId === n.id} {...ctx} />;
            if (r.kind === 'add') return <AddRow key={`add-${n.id}-${r.what}`} r={r} {...ctx} />;
            if (r.kind === 'total') return (
              <tr key={`tot-${n.id}`} className={`tot d${Math.min(r.depth, 2)}${dropCls(r)}`} {...dnd(r)}>
                {C.map((c) => {
                  if (c.role === 'label') return (
                    <td key={c.id} className="stick"><div className="lab" style={{ paddingLeft: r.depth * 18 + 30 }}>
                      <span className="txt">{n.total.label || `Total ${n.label}`}</span></div></td>
                  );
                  if (summed(c)) return <td key={c.id} className={`calc tot${c.role === 'row_total' ? ' rt' : ''}`}>{P.fmt(totals[n.id][c.id])}</td>;
                  return <td key={c.id} />;
                })}
                <td />
              </tr>
            );
            return null;
          })}
        </tbody>
      </table>
      <div className="gridfoot">
        <button className="btn sm" onClick={onAddSection}>＋ Add category</button>
        <button className="btn sm" onClick={onAddTopItem}>＋ Add single-line category</button>
        <span className="hint">
          Right-click a row for options · <kbd>Ctrl</kbd>+<kbd>Enter</kbd> adds a line below · paste rows from Excel into any cell · drag <span className="grip demo">⋮⋮</span> to move
        </span>
      </div>
    </div>
  );
}

/** an empty cell that still accepts a paste (category rows, add rows) */
const Zone = ({ id, col, append }) => <div className="zone" tabIndex={0} data-id={id} data-col={col} data-append={append ? '1' : undefined} />;

function GroupRow({ r, C, T, collapsed, autoFocus, update, commitEdit, onToggle, onNodeMenu, onAddMenu, grip, dnd, dropCls }) {
  const n = r.node, band = P.holdsLines(n), showSub = !n.total?.show || collapsed;
  const lines = P.countLines(n), info = n.definition || n.description;
  const canAdd = n.perms?.add_items !== false || n.perms?.add_groups;
  return (
    <tr id={`row-${n.id}`} data-row={n.id} className={`grp d${Math.min(r.depth, 2)} ${band ? 'band' : 'parent'}${dropCls(r)}`} {...dnd(r)}>
      {C.map((c) => {
        if (c.role === 'label') return (
          <td key={c.id} className="stick">
            <div className="lab" style={{ paddingLeft: r.depth * 18 }}>
              {grip(n) || <span className="grip off" />}
              <button className="ico chev" tabIndex={-1} onClick={() => onToggle(n.id)} aria-expanded={!collapsed} title={collapsed ? 'Expand' : 'Collapse'}>{collapsed ? '▸' : '▾'}</button>
              {n.perms?.rename !== false
                ? <TextCell node={n} col={c} value={n.label} update={update} commitEdit={commitEdit} autoFocus={autoFocus} ariaLabel={r.depth ? 'Sub-category name' : 'Category name'} />
                : <span className="txt grow name" title={`${n.label} – ${lines} line item${lines === 1 ? '' : 's'}`} tabIndex={0} data-id={n.id} data-col={c.id}>{n.label}</span>}
              {info && <span className="info" title={info}>i</span>}
              {n.exclude_from_parent_total && <span className="tag excl" title="Shown separately: not added to the parent total">not in total</span>}
              {n.origin === 'user' && <span className="tag user">custom</span>}
              <span className="acts">
                {canAdd && <button className="ico" tabIndex={-1} title="Add a line item or sub-category" onClick={(e) => onAddMenu(e.currentTarget, n.id)}>＋</button>}
                <button className="ico more" tabIndex={-1} title="More (or right-click the row)" onClick={(e) => onNodeMenu(e.currentTarget, n.id)}>⋯</button>
              </span>
            </div>
          </td>
        );
        if (c.role === 'definition') return <td key={c.id}><div className="defcell" title={n.definition}>{n.definition}</div></td>;
        if (showSub && summed(c)) return (
          <td key={c.id} className={`calc sub${c.role === 'row_total' ? ' rt' : ''}`} tabIndex={0} data-id={n.id} data-col={c.id}
            title={n.total?.show ? 'Collapsed – subtotal' : 'Subtotal'}>{blankZero(T[c.id])}</td>
        );
        return <td key={c.id} className={c.role === 'row_total' ? 'rt' : ''}><Zone id={n.id} col={c.id} /></td>;
      })}
      <td />
    </tr>
  );
}

/** a line broken down into sub-items (e.g. Hardware): its amounts are the subtotal of its sub-items */
function RollupRow({ r, C, T, collapsed, autoFocus, update, commitEdit, onToggle, onNodeMenu, onAddItem, grip, dnd, dropCls }) {
  const n = r.node;
  return (
    <tr id={`row-${n.id}`} data-row={n.id} className={`rollup${r.depth === 0 ? ' d0' : ''}${dropCls(r)}`} {...dnd(r)}>
      {C.map((c) => {
        if (c.role === 'label') return (
          <td key={c.id} className="stick">
            <div className="lab" style={{ paddingLeft: Math.max(r.depth - 1, 0) * 18 + 18 }}>
              {grip(n) || <span className="grip off" />}
              <button className="ico chev" tabIndex={-1} onClick={() => onToggle(n.id)} title={collapsed ? 'Show sub-items' : 'Hide sub-items'}>{collapsed ? '▸' : '▾'}</button>
              <TextCell node={n} col={c} value={n.label} update={update} commitEdit={commitEdit}
                readOnly={n.perms?.rename === false} autoFocus={autoFocus} title={n.description} ariaLabel="Line name" />
              <span className="tag sub" title="This row is the subtotal of its sub-items">Σ {n.children.length}</span>
              <span className="acts">
                <button className="ico" tabIndex={-1} title="Add sub-item" onClick={() => onAddItem(n.id)}>＋</button>
                <button className="ico more" tabIndex={-1} title="More (or right-click the row)" onClick={(e) => onNodeMenu(e.currentTarget, n.id)}>⋯</button>
              </span>
            </div>
          </td>
        );
        if (summed(c)) return <td key={c.id} className={`calc sub${c.role === 'row_total' ? ' rt' : ''}`}>{blankZero(T[c.id])}</td>;
        if (c.type === 'amount') return <td key={c.id} />;
        if (c.role === 'definition') return <td key={c.id}>{r.depth === 0 && <div className="defcell" title={n.definition}>{n.definition}</div>}</td>;
        return (
          <td key={c.id}>
            <TextCell node={n} col={c} value={n.values?.[c.id]} update={update} commitEdit={commitEdit}
              placeholder={c.type === 'date' ? 'DD/MM' : ''} ariaLabel={`${n.label} – ${c.label}`} />
          </td>
        );
      })}
      <td />
    </tr>
  );
}

function ItemRow({ r, C, T, issues, autoFocus, update, commitEdit, onNodeMenu, onBreakDown, grip, dnd, dropCls, emptyLines }) {
  const n = r.node, sub = r.parent && P.isRollup(r.parent);
  return (
    <tr id={`row-${n.id}`} data-row={n.id} className={`line${r.depth === 0 ? ' single' : ''}${sub ? ' subitem' : ''}${issues ? ' has-issue' : ''}${dropCls(r)}`} {...dnd(r)}>
      {C.map((c) => {
        if (c.role === 'label') return (
          <td key={c.id} className="stick">
            <div className="lab" style={{ paddingLeft: r.depth === 0 ? 0 : r.depth * 18 + 8 }}>
              {grip(n) || <span className="grip off" />}
              <TextCell node={n} col={c} value={n.label} update={update} commitEdit={commitEdit}
                readOnly={n.perms?.rename === false} autoFocus={autoFocus} title={n.description} ariaLabel="Line name" />
              {issues && <span className="warnmark" title={issues.join('\n')}>!</span>}
              {n.origin === 'user' && !sub && <span className="tag user">new</span>}
              <span className="acts">
                {r.depth > 0 && !sub && <button className="ico" tabIndex={-1} title="Split into sub-items (this row becomes their subtotal)" onClick={() => onBreakDown(n.id)}>⤷</button>}
                <button className="ico more" tabIndex={-1} title="More (or right-click the row)" onClick={(e) => onNodeMenu(e.currentTarget, n.id)}>⋯</button>
              </span>
            </div>
          </td>
        );
        if (c.type === 'formula') return <td key={c.id} className="calc rt">{emptyLines.has(n.id) ? '' : P.fmt(T[c.id])}</td>;
        if (c.role === 'definition') return <td key={c.id}>{r.depth === 0 && <div className="defcell" title={n.definition}>{n.definition}</div>}</td>;
        if (c.type === 'amount') return <td key={c.id}><AmountCell node={n} col={c} update={update} commitEdit={commitEdit} /></td>;
        return (
          <td key={c.id}>
            <TextCell node={n} col={c} value={n.values?.[c.id]} update={update} commitEdit={commitEdit}
              placeholder={c.type === 'date' ? 'DD/MM' : c.hint || ''} ariaLabel={`${n.label} – ${c.label}`} />
          </td>
        );
      })}
      <td />
    </tr>
  );
}

function AddRow({ r, C, onAddItem, onAddSub, dnd, dropCls }) {
  const n = r.node, rollup = P.isRollup(n), items = r.what.includes('items'), empty = !n.children.some(P.isLine);
  return (
    <tr className={`add${dropCls(r)}`} {...dnd(r)}>
      <td className="stick">
        <div className="addlinks" style={{ paddingLeft: r.depth * 18 + 22 }}>
          {items && empty && <span className="empty-note">No line items yet</span>}
          {items && <button className="link" onClick={() => onAddItem(n.id)}>＋ {rollup ? 'Add sub-item' : 'Add line item'}</button>}
          {r.what.includes('groups') && <button className="link" onClick={() => onAddSub(n.id)}>＋ Add sub-category</button>}
          {items && <Zone id={n.id} col={C[0].id} append />}
        </div>
      </td>
      {C.slice(1).map((c) => <td key={c.id} className={c.role === 'row_total' ? 'rt' : ''}>{items && <Zone id={n.id} col={c.id} append />}</td>)}
      <td />
    </tr>
  );
}
