import { useMemo, useState } from 'react';
import { Modal } from '../../components/ui';
import * as P from '../../lib/parCore';
import { layoutSheet } from '../../lib/sheetLayout';

/* ── Add a line item / sub-category / category (toolbar "＋ Add") ─────── */
const ADD_KINDS = [
  ['line', 'Line item', 'A row with amounts per fiscal year, e.g. “Cloud hosting”.'],
  ['sub', 'Sub-category', 'A group of line items inside a category, with its own subtotal.'],
  ['category', 'Category', 'A new top-level section with its own total.'],
];
const INDENT = '    ';

export function AddDialog({ doc, initial = {}, onAdd, onClose }) {
  const groups = useMemo(() => [...P.walk(doc.nodes)].filter(([n]) => n.type === 'group' && !P.isRollup(n))
    .map(([n, depth]) => ({ n, depth })), [doc]);
  const [kind, setKind] = useState(initial.kind || 'line');
  const [name, setName] = useState('');
  const [parentId, setParentId] = useState(initial.parentId || null);
  const options = kind === 'category' ? [] : groups.filter(({ n }) => (kind === 'line' ? n.perms?.add_items !== false : !!n.perms?.add_groups));
  const parent = options.some((o) => o.n.id === parentId) ? parentId : options[0]?.n.id;
  const submit = () => { if (kind === 'category' || parent) onAdd({ kind, name: name.trim(), parentId: kind === 'category' ? null : parent }); };

  return (
    <Modal title="Add" onClose={onClose}
      footer={<><button className="btn" onClick={onClose}>Cancel</button>
        <button className="btn pri" disabled={kind !== 'category' && !parent} onClick={submit}>Add</button></>}>
      <div className="radios">
        {ADD_KINDS.map(([k, title, text]) => (
          <label key={k}><input type="radio" name="add-kind" checked={kind === k} onChange={() => setKind(k)} />
            <span><b>{title}</b><small>{text}</small></span></label>
        ))}
      </div>
      <div className="fld"><label>Name</label>
        <input type="text" value={name} autoFocus autoComplete="off"
          placeholder={{ line: 'e.g. Cloud hosting', sub: 'e.g. Cloud costs', category: 'e.g. Vendor contracts' }[kind]}
          onChange={(e) => setName(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && submit()} /></div>
      {kind !== 'category' && (
        <div className="fld"><label>{kind === 'line' ? 'Add it to' : 'Put it inside'}</label>
          <select value={parent || ''} onChange={(e) => setParentId(e.target.value)}>
            {options.map(({ n, depth }) => <option key={n.id} value={n.id}>{INDENT.repeat(depth)}{n.label}</option>)}
          </select></div>
      )}
    </Modal>
  );
}

/* ── Add / edit column ─────────────────────────────────────────────────── */
const KINDS = [
  ['period', 'Amount – counts in row Total', 'e.g. FY 6, Q1 2028. Summed into Total and every category total.'],
  ['amount', 'Amount – separate', 'e.g. Spend to Date. Own subtotal, not part of Total.'],
  ['text', 'Text', 'Notes, owner, vendor…'],
  ['date', 'Date', 'DD/MM'],
];
const kindOf = (c) => (c.type === 'amount' ? (c.role === 'period' ? 'period' : 'amount') : c.type);

export function ColumnModal({ doc, column, onSubmit, onClose }) {
  const periods = P.periodCols(doc);
  const [label, setLabel] = useState(column ? column.label : `FY ${periods.length + 1}`);
  const [kind, setKind] = useState(column ? kindOf(column) : 'period');
  const [afterId, setAfterId] = useState(periods[periods.length - 1]?.id || doc.columns[doc.columns.length - 1].id);
  const [group, setGroup] = useState(column?.group || '');
  const typeLocked = column && (column.origin !== 'user' || column.type === 'formula');
  const submit = () => { if (label.trim()) onSubmit({ label: label.trim(), kind, afterId, group: group.trim() || null }); };

  return (
    <Modal title={column ? 'Edit column' : 'Add column'} onClose={onClose}
      footer={<><button className="btn" onClick={onClose}>Cancel</button>
        <button className="btn pri" onClick={submit}>{column ? 'Apply' : 'Add column'}</button></>}>
      <div className="fld"><label>Column name</label>
        <input type="text" value={label} autoFocus onFocus={(e) => e.target.select()} onChange={(e) => setLabel(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && submit()} /></div>
      <div className="fld"><label>Type{typeLocked ? ' (locked by template)' : ''}</label>
        <div className="radios">
          {KINDS.map(([v, t, s]) => (
            <label key={v}><input type="radio" name="kind" checked={kind === v} disabled={typeLocked} onChange={() => setKind(v)} />
              <span><b>{t}</b><small>{s}</small></span></label>
          ))}
        </div></div>
      {!column && (
        <div className="fld"><label>Insert after</label>
          <select value={afterId} onChange={(e) => setAfterId(e.target.value)}>
            {doc.columns.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}
          </select></div>
      )}
      <div className="fld"><label>Header group (optional)</label>
        <input type="text" value={group} placeholder="e.g. Cost Recovery" onChange={(e) => setGroup(e.target.value)} /></div>
    </Modal>
  );
}

/* ── Category / sub-category settings ──────────────────────────────────── */
export function GroupModal({ node, depth, onSubmit, onClose }) {
  const [label, setLabel] = useState(node.label);
  const [definition, setDefinition] = useState(node.definition || '');
  const [totalLabel, setTotalLabel] = useState(node.total?.label || `Total ${node.label}`);
  const locked = node.perms?.rename === false;
  return (
    <Modal title={depth ? 'Sub-category settings' : 'Category settings'} onClose={onClose}
      footer={<><button className="btn" onClick={onClose}>Cancel</button>
        <button className="btn pri" onClick={() => onSubmit({ label, definition, total: { label: totalLabel } })}>Apply</button></>}>
      <div className="fld"><label>Name{locked ? ' (locked by template)' : ''}</label>
        <input type="text" value={label} readOnly={locked} onChange={(e) => setLabel(e.target.value)} /></div>
      <div className="fld"><label>Definition (shown in the Definition column of the export)</label>
        <textarea rows={3} value={definition} onChange={(e) => setDefinition(e.target.value)} /></div>
      <div className="fld"><label>Total row label</label>
        <input type="text" value={totalLabel} onChange={(e) => setTotalLabel(e.target.value)} /></div>
    </Modal>
  );
}

/* ── Export to Excel ───────────────────────────────────────────────────── */
export function ExportDialog({ doc, parId, options, onChange, onExport, onPreview, onClose }) {
  const [name, setName] = useState(`PAR_Financial_${parId}.xlsx`);
  // what each switch would remove (lines first, then the groups left empty)
  const empties = useMemo(() => layoutSheet(doc, { removeEmptyLines: true, removeEmptySubcategories: true, removeEmptyCategories: true }).removed, [doc]);
  const set = (k) => (e) => onChange({ ...options, [k]: e.target.checked });
  const file = name.trim().replace(/\.xlsx$/i, '') + '.xlsx';
  return (
    <Modal title="Export to Excel" onClose={onClose}
      footer={<><button className="btn" onClick={onPreview}>Preview the sheet</button><span className="grow" />
        <button className="btn" onClick={onClose}>Cancel</button>
        <button className="btn pri" onClick={() => onExport(file)}>⬇ Export .xlsx</button></>}>
      <div className="hint">The file uses the layout of the PAR Financial Template: instructions, the light-blue category rows, grey totals
        and live <code>=SUM()</code> formulas. Nested sub-categories and sub-items become indented rows.</div>
      <div className="checks">
        <label><input type="checkbox" checked={options.removeEmptyLines} onChange={set('removeEmptyLines')} />
          <span><b>Remove empty line items</b><small>{empties.lines} line{empties.lines === 1 ? '' : 's'} without amounts or notes</small></span></label>
        <label><input type="checkbox" checked={options.removeEmptySubcategories} disabled={!options.removeEmptyLines} onChange={set('removeEmptySubcategories')} />
          <span><b>Also remove sub-categories that have no lines</b><small>{empties.subcategories} would go</small></span></label>
        <label><input type="checkbox" checked={options.removeEmptyCategories} disabled={!options.removeEmptyLines} onChange={set('removeEmptyCategories')} />
          <span><b>Also remove empty categories</b><small>{empties.categories} would go – by default every category of the form is kept</small></span></label>
        <label><input type="checkbox" checked={options.includeInstructions} onChange={set('includeInstructions')} />
          <span><b>Include the instructions block</b><small>Rows 2–11 of the form</small></span></label>
      </div>
      <div className="fld"><label>File name</label>
        <input type="text" value={name} onChange={(e) => setName(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && onExport(file)} /></div>
    </Modal>
  );
}
