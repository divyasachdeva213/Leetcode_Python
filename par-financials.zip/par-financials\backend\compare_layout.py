"""
Compare an exported PAR financial sheet with the reference form, cell by cell.

    python compare_layout.py exported.xlsx PAR_Financial_Filled.xlsx

Prints every difference in values, formulas, fills (light-blue band / grey), bold, borders, merged
cells and column widths, so a change to the export layout can be checked against the signed-off form.
Exit code 0 = identical apart from the differences listed in --allow (substring match), 1 otherwise.
"""
import argparse
import re
import sys

import openpyxl

COLS = "BCDEFGHIJKLMNO"


def fill_kind(cell):
    f = cell.fill
    if f is None or not f.fill_type or f.fill_type == "none":
        return "-"
    c = f.fgColor
    if c.type == "theme":
        return {4: "band", 0: "grey" if (c.tint or 0) < 0 else "-"}.get(c.theme, f"theme{c.theme}")
    rgb = (c.rgb or "").upper()
    return {"FFC1E5F5": "band", "FFBFBFBF": "grey", "FFFFFFFF": "-", "00000000": "-"}.get(rgb, rgb)


def value(cell):
    v = cell.value
    if isinstance(v, str):
        v = re.sub(r"\s+", " ", v).strip()
        return v[1:] if v.startswith("=") else v
    return v


def border(cell):
    b = cell.border
    return "".join(f"{k}{(getattr(b, n).style or '-')[0]}" for k, n in (("t", "top"), ("b", "bottom"), ("l", "left"), ("r", "right")))


def compare(a_path, b_path, last_row=None):
    a = openpyxl.load_workbook(a_path).worksheets[0]
    b = openpyxl.load_workbook(b_path).worksheets[0]
    diffs = []
    rows = last_row or max(a.max_row, b.max_row)
    for r in range(1, rows + 1):
        for col in COLS:
            ca, cb = a[f"{col}{r}"], b[f"{col}{r}"]
            checks = (("value", value(ca), value(cb)), ("fill", fill_kind(ca), fill_kind(cb)),
                      ("bold", bool(ca.font.b), bool(cb.font.b)), ("border", border(ca), border(cb)))
            for what, x, y in checks:
                if what == "bold" and value(ca) in (None, "") and value(cb) in (None, ""):
                    continue
                if x != y and not (what == "value" and {x, y} <= {None, 0, ""}):
                    diffs.append(f"{col}{r} {what}: export={x!r} form={y!r}")
    ma = sorted(str(m) for m in a.merged_cells.ranges)
    mb = sorted(str(m) for m in b.merged_cells.ranges)
    if ma != mb:
        diffs.append(f"merged cells: export={ma} form={mb}")
    for col, dim in b.column_dimensions.items():  # only the widths the form sets explicitly
        wa = a.column_dimensions[col].width if col in a.column_dimensions else None
        if dim.customWidth and abs((wa or 0) - (dim.width or 0)) > 0.05:
            diffs.append(f"width {col}: export={wa} form={dim.width}")
    return diffs


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("export")
    ap.add_argument("form")
    ap.add_argument("--allow", action="append", default=[], help="ignore differences containing this text")
    ap.add_argument("--rows", type=int, default=None, help="compare rows 1..N only")
    args = ap.parse_args()
    diffs = compare(args.export, args.form, args.rows)
    shown = [d for d in diffs if not any(s in d for s in args.allow)]
    for d in shown:
        print(d)
    print(f"{len(diffs)} difference(s), {len(diffs) - len(shown)} allowed, {len(shown)} to review")
    return 1 if shown else 0


if __name__ == "__main__":
    sys.exit(main())
