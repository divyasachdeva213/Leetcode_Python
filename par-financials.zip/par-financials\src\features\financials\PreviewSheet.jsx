import { useMemo } from 'react';
import * as P from '../../lib/parCore';
import { layoutSheet } from '../../lib/sheetLayout';

const px = (w) => Math.round(w * 7 + 6);
const line = (s) => (s === 'medium' ? '2px solid #262b33' : s === 'thin' ? '1px solid #9aa1ab' : undefined);
const FILL = { band: '#c1e5f5', grey: '#bfbfbf' };

function show(spec) {
  if (!spec || spec.v == null || spec.v === '') return '';
  if (spec.numFmt && typeof spec.v === 'number') return P.fmt(spec.v);
  return String(spec.v);
}

/** Read-only rendering of the export: the same layoutSheet() rows, values, formulas and styles as the .xlsx. */
export default function PreviewSheet({ doc, options, onOptions }) {
  const lay = useMemo(() => layoutSheet(doc, options), [doc, options]);
  const byN = useMemo(() => new Map(lay.rows.map((r) => [r.n, r])), [lay]);
  const letters = lay.columns.map((c) => lay.letters[c.id]);
  const rows = [];
  for (let n = 1; n <= lay.lastRow; n++) rows.push(byN.get(n) || { n, kind: 'blank', cells: {} });
  const merged = new Map(lay.merges.map((m) => { const [a, b] = m.split(':'); return [a.replace(/\d+/g, ''), { to: b.replace(/\d+/g, ''), row: +a.replace(/\D+/g, '') }]; }));

  const removed = lay.removed;
  const note = options.removeEmptyLines
    ? `${removed.lines} empty line${removed.lines === 1 ? '' : 's'} left out${removed.subcategories ? `, ${removed.subcategories} empty sub-categor${removed.subcategories === 1 ? 'y' : 'ies'}` : ''}${removed.categories ? `, ${removed.categories} empty categor${removed.categories === 1 ? 'y' : 'ies'}` : ''}`
    : 'every line included';

  return (
    <div className="preview">
      <div className="sheetbar">
        <span>This is exactly what <b>Export</b> downloads: {note}. Totals are live <code>=SUM()</code> formulas.</span>
        <span className="grow" />
        <button className="btn sm" onClick={onOptions}>Export options…</button>
      </div>
      <div className="sheet">
        <table style={{ width: 40 + px(lay.widths.A) + lay.columns.reduce((a, c) => a + px(lay.widths[lay.letters[c.id]]), 0) }}>
          <colgroup>
            <col style={{ width: 40 }} />
            <col style={{ width: px(lay.widths.A) }} />
            {lay.columns.map((c) => <col key={c.id} style={{ width: px(lay.widths[lay.letters[c.id]]) }} />)}
          </colgroup>
          <thead>
            <tr className="colhdr"><th className="rn" /><th>A</th>{letters.map((l) => <th key={l}>{l}</th>)}</tr>
          </thead>
          <tbody>
            {rows.map((r) => {
              if (r.kind === 'instructions') {
                const spec = r.cells[lay.columns[0].id];
                return <tr key={r.n}><td className="rn">{r.n}</td><td /><td className="ins" colSpan={lay.columns.length}>{spec?.v}</td></tr>;
              }
              const cells = [];
              for (let k = 0; k < lay.columns.length; k++) {
                const c = lay.columns[k], L = lay.letters[c.id], s = r.cells[c.id];
                const m = merged.get(L);
                let span = 1;
                if (m && m.row === r.n) span = letters.indexOf(m.to) - k + 1;
                const style = s ? {
                  background: s.fill ? FILL[s.fill] : undefined, fontWeight: s.bold ? 700 : undefined, fontStyle: s.italic ? 'italic' : undefined,
                  textAlign: s.h || (s.numFmt ? 'right' : undefined), verticalAlign: s.vAlign === 'center' ? 'middle' : s.vAlign || 'bottom',
                  whiteSpace: s.wrap ? 'normal' : 'nowrap', paddingLeft: s.indent ? 6 + s.indent * 14 : undefined,
                  borderTop: line(s.border?.t), borderBottom: line(s.border?.b), borderLeft: line(s.border?.l), borderRight: line(s.border?.r),
                } : undefined;
                cells.push(
                  <td key={c.id} colSpan={span} style={style} className={s?.f ? 'f' : undefined} title={s?.f ? `=${s.f}` : undefined}>
                    {show(s)}
                  </td>,
                );
                k += span - 1;
              }
              return (
                <tr key={r.n} style={r.height ? { height: Math.round(r.height * 1.333) } : undefined}>
                  <td className="rn">{r.n}</td><td />{cells}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <div className="sheettabs"><span>{lay.sheetName}</span></div>
    </div>
  );
}
