# PAR Financials

The Financials tab of the PAR Workbench: a chat window on the left and the financials on the right. Users build the
financials themselves (categories, sub-categories, line items, sub-items, any number of fiscal years), paste rows from
Excel, upload a filled PAR Excel (in the tab or through the chat), and export a clean `.xlsx` in the layout of the
PAR Financial Template. No AI is involved: imports are rule-based and shown for review before they are applied.

## Run it on a new laptop

**You need:** Node.js 20 or newer (npm 10+) from https://nodejs.org (LTS). Python 3.10+ only for the database backend.

**Copy** the `par-financials` folder **without** `node_modules`, `dist`, `backend/.venv` and `backend/par.db`
(copy `par.db` only if you want to keep data saved through the backend). Then, in the folder:

```bash
npm ci                 # installs the exact library versions from package-lock.json
npm run dev            # http://localhost:5173 – data is saved in this browser
```

**With the database backend** (data in `backend/par.db`, version history, "saved elsewhere" warning):

```bash
python -m venv backend/.venv
backend\.venv\Scripts\pip install -r backend/requirements.txt      # macOS/Linux: backend/.venv/bin/pip install …
npm run dev:all        # UI on http://localhost:5173, API on http://localhost:8000
```

**Check the install:** `npm test` (engine, 26 tests) · `npm run build` · `cd backend` then `python -m unittest test_api.py` (API, 5 tests).

## The JSON

| What | Where | Needed? |
|---|---|---|
| **Template** – categories, sub-categories, default lines, columns, definitions, instructions, rules | `src/data/par_template_v3.json` | **Yes** – the app loads it on start |
| Same template, for the backend | `backend/par_template_v3.json` | Yes with the backend – keep it identical to the one above |
| **A PAR's financials** – one JSON document (columns + nodes + values); totals are never stored | browser mode: this browser's storage · backend: `backend/par.db` | Move it with **⋯ → Saved data (JSON) → Download JSON**, then **Load JSON** on the other laptop (or copy `par.db`) |

When the template changes, edit both template files and raise `template_version`; existing PARs keep the version they
were created with.

## What users can do

- **Build the structure:** `＋ Add ▾` in the toolbar (category, sub-category, line item), the ＋ on a category row,
  "+ Add line item" at the end of each section, right-click any row, `Ctrl+Enter` for a new line below. Lines can be split
  into sub-items, dragged to another category, renamed, duplicated, deleted. The form's standard categories are locked.
- **Totals everywhere:** line totals, sub-category and category totals, top-level chips; undo/redo; autosave.
- **Fiscal years:** `Fiscal years [−] 5 [+]` – type 10 or 15; FY 1–5 of the form always stay.
- **Paste from Excel:** into any cell (values spread right and down, lines are added), or whole tables with sections.
- **Import:** upload `.xlsx`/`.csv` (or drop it on the tab or the chat) → a row-by-row review → apply.
- **Export:** `⬇ Export ▾` → the exact PAR layout with live `=SUM()` formulas; empty line items are left out (switches
  for empty sub-categories/categories); **Excel preview** shows the file before downloading; **blank template** download.

## Rules worth knowing

- An **empty line** has no amount and no notes/text (the name doesn't count). The export drops empty lines only;
  every category and sub-category header stays, like the form.
- **Import, "Update & add":** amounts and text in the file update matching lines; blank and `0` cells keep what is
  already there (the form pre-fills every cell with 0). **"Replace with this file"** takes the file exactly as it is.
  Matching tolerates small typos ("Contigency") and "(describe)" suffixes; empty "Item 1…4" rows are skipped; "Total …"
  rows are recognised and their numbers checked against the recalculated totals.
- **Variable Cost Items** sits inside Ongoing Expense Items, so "Total Ongoing Costs" includes it (as in the form).
  Cost Avoidance is shown with its own total and is not added to the expense total.

## Files

| File | What it does |
|---|---|
| `src/lib/parCore.js` | Engine: tree, totals, validation, empty-line rules, number parsing (`1,234`, `(500)`, `15k`) |
| `src/lib/docOps.js` | Every edit: add/move/delete, paste, split into sub-items, fiscal years, columns |
| `src/lib/importer.js` | Reading `.xlsx`/`.csv`, header + column mapping, row classification, the import report |
| `src/lib/sheetLayout.js` · `excelExport.js` · `exportXlsx.js` | The export layout (rows, styles, formulas) → `.xlsx`; the Excel preview uses the same layout |
| `src/state/useFinancialDoc.js` · `useStored.js` | Loading, undo/redo, autosave with versions; view preferences |
| `src/api/financialsApi.js` | The HTTP contract with the backend, plus the in-browser version |
| `src/features/financials/*` | The tab: grid, cells, import review, dialogs, Excel preview, JSON view |
| `src/features/chat/ChatPanel.jsx` · `src/App.jsx` | The chat window (your chatbot plugs in here) and the split layout |
| `backend/main.py` · `par_engine.py` | FastAPI + SQLite/Postgres (`DATABASE_URL`): versions, history, reporting table, server-side totals |
| `backend/compare_layout.py` | Compares an exported sheet with the reference form, cell by cell |
| `src/lib/*.test.js` · `backend/test_api.py` · `test/fixtures/` | Tests (the fixture is the reference PAR form) |
