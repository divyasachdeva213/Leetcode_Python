/**
 * API layer for the Financials tab.
 *
 * Real backend contract (backend/main.py):
 *   GET  /api/templates/{templateId}/versions/{version}   -> template JSON (par_template_v3.json)
 *   GET  /api/templates/{templateId}/latest                -> newest template version (fallback)
 *   GET  /api/pars/{parId}/financials                      -> saved document + {version, saved_at} | 404
 *   PUT  /api/pars/{parId}/financials                      -> body = document + base_version; 409 if someone saved in between
 *   GET  /api/pars/{parId}/financials/versions             -> [{version, saved_at, saved_by, note}]
 *
 * With VITE_USE_MOCK_API !== 'false' a localStorage mock with the same behaviour is used, so the app runs with no backend.
 */
import templateV3 from '../data/par_template_v3.json';

const USE_MOCK = import.meta.env?.VITE_USE_MOCK_API !== 'false';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** the document was saved by someone else since it was loaded; info = {current_version, saved_at, saved_by} */
export class ConflictError extends Error {
  constructor(info = {}) {
    super(info.message || 'These financials were saved by someone else in the meantime.');
    this.name = 'ConflictError';
    this.info = info;
  }
}

// ── real HTTP ───────────────────────────────────────────────────────────────
async function http(method, url, body) {
  const res = await fetch(url, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  if (res.status === 404) return null;
  const json = await res.json().catch(() => null);
  if (res.status === 409) throw new ConflictError(json?.detail || {});
  if (!res.ok) {
    const d = json?.detail;
    throw new Error(typeof d === 'string' ? d : d ? JSON.stringify(d) : `${method} ${url} → ${res.status}`);
  }
  return json;
}

const httpApi = {
  getTemplate: async (id, ver) => (await http('GET', `/api/templates/${id}/versions/${ver}`)) || http('GET', `/api/templates/${id}/latest`),
  getFinancials: (parId) => http('GET', `/api/pars/${parId}/financials`),
  saveFinancials: (parId, body) => http('PUT', `/api/pars/${parId}/financials`, body),
  listVersions: (parId) => http('GET', `/api/pars/${parId}/financials/versions`).then((v) => v || []),
};

// ── mock (localStorage) ─────────────────────────────────────────────────────
const store = {
  get(k) { try { return JSON.parse(localStorage.getItem(k)); } catch { return null; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* private mode etc. */ } },
  del(k) { try { localStorage.removeItem(k); } catch { /* ignore */ } },
};
const TEMPLATES = { [`${templateV3.template_id}@${templateV3.template_version}`]: templateV3 };

const mockApi = {
  async getTemplate(id, ver) {
    await sleep(150);
    // a PAR stays on its template version; if that version is gone, the newest one is used
    const t = TEMPLATES[`${id}@${ver}`] || Object.values(TEMPLATES).find((x) => x.template_id === id);
    if (!t) throw new Error(`Template ${id}@${ver} not found`);
    return structuredClone(t);
  },
  async getFinancials(parId) {
    await sleep(150);
    return store.get(`par:${parId}:financials`);
  },
  async saveFinancials(parId, body) {
    await sleep(150);
    const cur = store.get(`par:${parId}:financials`);
    if (cur && body.base_version !== cur.version) {
      throw new ConflictError({ current_version: cur.version, saved_at: cur.saved_at, saved_by: 'another tab' });
    }
    const { base_version, ...doc } = body;
    const meta = { version: (cur?.version || 0) + 1, saved_at: new Date().toISOString() };
    store.set(`par:${parId}:financials`, { ...doc, ...meta });
    const versions = store.get(`par:${parId}:versions`) || [];
    versions.push({ ...meta, saved_by: 'you' });
    store.set(`par:${parId}:versions`, versions);
    return meta;
  },
  async listVersions(parId) {
    return store.get(`par:${parId}:versions`) || [];
  },
  async clear(parId) {
    store.del(`par:${parId}:financials`);
    store.del(`par:${parId}:versions`);
  },
};

export const api = USE_MOCK ? mockApi : httpApi;
export const DEFAULT_TEMPLATE = { id: templateV3.template_id, version: templateV3.template_version };
export const usingMock = USE_MOCK;
