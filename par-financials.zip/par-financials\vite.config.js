import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { viteSingleFile } from 'vite-plugin-singlefile';

// `npm run build:single` produces one self-contained dist/index.html (handy for demos)
export default defineConfig(({ mode }) => ({
  plugins: [react(), ...(mode === 'single' ? [viteSingleFile()] : [])],
  server: {
    port: 5173,
    // point /api at your backend (FastAPI etc.) when VITE_USE_MOCK_API=false
    proxy: { '/api': 'http://localhost:8000' },
  },
}));
