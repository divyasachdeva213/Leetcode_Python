import { useEffect, useRef, useState } from 'react';
import * as P from '../../lib/parCore';

const kb = (n) => (n > 1024 * 1024 ? `${(n / 1024 / 1024).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`);

/**
 * The chat window on the left. Your chatbot plugs in here; in this prototype the assistant is not connected,
 * but attaching an Excel file or pasting rows copied from Excel hands them to the Financials import review.
 *   onSend(text) · onAttach(file) · onPasteTable(text) · onImportText(text) · onClose()
 */
export default function ChatPanel({ messages, onSend, onAttach, onPasteTable, onImportText, onClose }) {
  const [text, setText] = useState('');
  const [over, setOver] = useState(false);
  const fileRef = useRef(null), listRef = useRef(null);

  useEffect(() => { listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: 'smooth' }); }, [messages.length]);

  const send = () => { const t = text.trim(); if (t) { onSend(t); setText(''); } };
  const onPaste = (e) => {
    const t = e.clipboardData.getData('text/plain');
    const rows = P.parseTSV(t.replace(/\r?\n$/, ''));
    if (/\t/.test(t) && (rows.length >= 2 || rows[0].length >= 3)) { e.preventDefault(); onPasteTable(t); }
  };
  const onDrop = (e) => {
    e.preventDefault();
    setOver(false);
    const f = e.dataTransfer.files?.[0];
    if (f) onAttach(f);
  };

  return (
    <aside className={`chat${over ? ' over' : ''}`} aria-label="Chat"
      onDragOver={(e) => { if ([...(e.dataTransfer?.types || [])].includes('Files')) { e.preventDefault(); setOver(true); } }}
      onDragLeave={(e) => { if (!e.currentTarget.contains(e.relatedTarget)) setOver(false); }}
      onDrop={onDrop}>
      <div className="chat-head">
        <span className="avatar">PA</span>
        <span className="who"><b>PAR Assistant</b><small>assistant not connected · prototype</small></span>
        <span className="grow" />
        <button className="ico" title="Hide chat" aria-label="Hide chat" onClick={onClose}>⟨</button>
      </div>
      <div className="chat-list" ref={listRef}>
        {messages.map((m) => <Message key={m.id} m={m} onImportText={onImportText} />)}
      </div>
      {over && <div className="chat-drop">Drop the Excel file to import it into Financials</div>}
      <div className="chat-compose">
        <button className="ico big" title="Attach an Excel or CSV file" aria-label="Attach file" onClick={() => fileRef.current.click()}>📎</button>
        <textarea rows={1} value={text} placeholder="Message, or paste rows from Excel…" aria-label="Message"
          onChange={(e) => setText(e.target.value)} onPaste={onPaste}
          onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }} />
        <button className="btn pri sm" disabled={!text.trim()} onClick={send}>Send</button>
        <input ref={fileRef} type="file" hidden accept=".xlsx,.xlsm,.csv,.tsv,.xls"
          onChange={(e) => { const f = e.target.files[0]; if (f) onAttach(f); e.target.value = ''; }} />
      </div>
    </aside>
  );
}

function Message({ m, onImportText }) {
  if (m.role === 'user' && m.file) return <div className="msg me att">📄 {m.file.name}<small>{kb(m.file.size || 0)}</small></div>;
  if (m.role === 'user' && m.table) {
    const rows = P.parseTSV(m.table.replace(/\r?\n$/, ''));
    const cols = Math.max(...rows.map((r) => r.length));
    return (
      <div className="msg me">
        <div className="tbl-head">📋 Rows copied from Excel · {rows.length} × {cols}</div>
        <table className="tbl-prev"><tbody>
          {rows.slice(0, 4).map((r, i) => <tr key={i}>{r.slice(0, 5).map((v, j) => <td key={j}>{v}</td>)}</tr>)}
        </tbody></table>
        {rows.length > 4 && <small>… {rows.length - 4} more row{rows.length - 4 > 1 ? 's' : ''}</small>}
        <button className="btn sm" onClick={() => onImportText(m.table)}>Import to Financials</button>
      </div>
    );
  }
  if (m.role === 'user') return <div className="msg me">{m.text}</div>;
  if (m.role === 'system') return <div className={`msg sys ${m.tone || ''}`}>{m.text}</div>;
  return <div className="msg bot">{m.text}</div>;
}
