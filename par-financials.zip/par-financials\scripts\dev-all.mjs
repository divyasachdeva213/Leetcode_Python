// npm run dev:all – the FastAPI backend (port 8000, SQLite in backend/par.db) + the UI (Vite) on the real API.
// Python: $PYTHON, else a virtual environment (backend/.venv, .venv, or ../../venv), else python on the PATH.
import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const venv = ['backend/.venv', '.venv', '../../venv']
  .flatMap((v) => [path.resolve(root, v, 'Scripts/python.exe'), path.resolve(root, v, 'bin/python')])
  .find(existsSync);
const python = process.env.PYTHON || venv || (process.platform === 'win32' ? 'python' : 'python3');

const procs = [
  spawn(python, ['-m', 'uvicorn', 'main:app', '--port', '8000', '--reload'], { cwd: path.join(root, 'backend'), stdio: 'inherit' }),
  spawn(process.execPath, [path.join(root, 'node_modules', 'vite', 'bin', 'vite.js')], {
    cwd: root, stdio: 'inherit', env: { ...process.env, VITE_USE_MOCK_API: 'false' },
  }),
];
const stop = () => procs.forEach((p) => p.exitCode == null && p.kill());
process.on('SIGINT', stop);
process.on('SIGTERM', stop);
procs.forEach((p, i) => p.on('exit', (code) => {
  if (code) console.error(`${i ? 'vite' : 'uvicorn'} stopped (exit ${code}) – is "pip install fastapi uvicorn sqlalchemy openpyxl" done?`);
  stop();
  process.exitCode = code || 0;
}));
