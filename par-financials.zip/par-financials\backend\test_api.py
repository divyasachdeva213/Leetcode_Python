"""
API tests for the Financials backend (throwaway SQLite database).

    python -m unittest test_api.py -v
"""
import copy
import json
import os
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).parent
os.environ["DATABASE_URL"] = f"sqlite:///{Path(tempfile.mkdtemp()) / 'test.db'}"

from fastapi.testclient import TestClient  # noqa: E402

import main  # noqa: E402

TPL = json.loads((HERE / "par_template_v3.json").read_text(encoding="utf-8"))
PAR = "PAR-TEST-1"


def payload(base_version=None, **values_by_id):
    doc = copy.deepcopy(TPL)
    for n, _, _ in main.E.walk(doc["nodes"]):
        if n["id"] in values_by_id:
            n["values"] = values_by_id[n["id"]]
    return {"par_id": PAR, "template_id": doc["template_id"], "template_version": doc["template_version"],
            "columns": doc["columns"], "nodes": doc["nodes"], "base_version": base_version}


class FinancialsApi(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.api = TestClient(main.app)

    def test_1_template_and_empty_par(self):
        r = self.api.get(f"/api/templates/{TPL['template_id']}/versions/{TPL['template_version']}")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()["template_version"], "3.1")
        self.assertEqual(self.api.get(f"/api/templates/{TPL['template_id']}/latest").json()["template_version"], "3.1")
        self.assertEqual(self.api.get(f"/api/pars/{PAR}/financials").status_code, 404)

    def test_2_save_versions_and_conflicts(self):
        r = self.api.put(f"/api/pars/{PAR}/financials", json=payload(ASSET_HARDWARE={"fy2": 2027}), headers={"X-User": "divya"})
        self.assertEqual(r.status_code, 200, r.text)
        self.assertEqual(r.json()["version"], 1)
        self.assertEqual(r.json()["totals"]["ASSETS"]["total"], 2027)

        r = self.api.put(f"/api/pars/{PAR}/financials", json=payload(1, ASSET_HARDWARE={"fy2": 2027, "fy3": 10}))
        self.assertEqual(r.json()["version"], 2)

        stale = self.api.put(f"/api/pars/{PAR}/financials", json=payload(1, ASSET_HARDWARE={"fy1": 1}))
        self.assertEqual(stale.status_code, 409)
        self.assertEqual(stale.json()["detail"]["current_version"], 2)
        self.assertEqual(self.api.put(f"/api/pars/{PAR}/financials", json=payload(None)).status_code, 409)

        got = self.api.get(f"/api/pars/{PAR}/financials").json()
        self.assertEqual(got["version"], 2)
        hw = next(n for n, _, _ in main.E.walk(got["nodes"]) if n["id"] == "ASSET_HARDWARE")
        self.assertEqual(hw["values"], {"fy2": 2027, "fy3": 10})

    def test_3_history_restore_and_projection(self):
        versions = self.api.get(f"/api/pars/{PAR}/financials/versions").json()
        self.assertEqual([v["version"] for v in versions], [1, 2])
        self.assertEqual(versions[0]["saved_by"], "divya")
        r = self.api.post(f"/api/pars/{PAR}/financials/restore/1")
        self.assertEqual(r.json()["version"], 3)
        self.assertEqual(self.api.get(f"/api/pars/{PAR}/financials/versions").json()[-1]["note"], "restored version 1")
        lines = self.api.get(f"/api/pars/{PAR}/financials/lines").json()
        self.assertEqual([(x["node_id"], x["column_id"], x["amount"], x["version"]) for x in lines], [("ASSET_HARDWARE", "fy2", 2027, 3)])
        self.assertEqual(lines[0]["path"], "Assets › Hardware")
        self.assertEqual(self.api.get(f"/api/pars/{PAR}/financials/totals").json()["ASSETS"]["total"], 2027)

    def test_4_shape_checks_and_server_validation(self):
        bad = payload(3)
        bad["nodes"][0]["children"][1]["id"] = bad["nodes"][0]["children"][0]["id"]
        self.assertEqual(self.api.put(f"/api/pars/{PAR}/financials", json=bad).status_code, 422)
        bad = payload(3)
        bad["columns"][1]["role"] = "label"
        self.assertEqual(self.api.put(f"/api/pars/{PAR}/financials", json=bad).status_code, 422)

        p = payload(3, ONGOING_FTE={"fy1": 1000, "ghost_column": 5}, ASSET_SOFTWARE={"fy1": "TBD"})
        r = self.api.put(f"/api/pars/{PAR}/financials", json=p)
        self.assertEqual(r.status_code, 200, r.text)
        msgs = {(i["node"], i["msg"]) for i in r.json()["issues"]}
        self.assertIn(("ONGOING_FTE", "Add notes/assumptions for this line"), msgs)
        self.assertIn(("ASSET_SOFTWARE", "FY 1: “TBD” is not a number"), msgs)
        got = self.api.get(f"/api/pars/{PAR}/financials").json()
        fte = next(n for n, _, _ in main.E.walk(got["nodes"]) if n["id"] == "ONGOING_FTE")
        self.assertEqual(fte["values"], {"fy1": 1000})  # values for unknown columns are dropped


    def test_5_many_fiscal_years(self):
        p = payload(self.api.get(f"/api/pars/{PAR}/financials").json()["version"])
        notes_at = next(i for i, c in enumerate(p["columns"]) if c["id"] == "notes")
        p["columns"][notes_at:notes_at] = [{"id": f"fy{n}", "label": f"FY {n}", "type": "amount", "role": "period",
                                            "aggregate": "sum", "origin": "user"} for n in range(6, 16)]
        hw = next(n for n, _, _ in main.E.walk(p["nodes"]) if n["id"] == "ASSET_HARDWARE")
        hw["values"] = {"fy1": 1, "fy15": 100}
        r = self.api.put(f"/api/pars/{PAR}/financials", json=p)
        self.assertEqual(r.status_code, 200, r.text)
        self.assertEqual(r.json()["totals"]["ASSETS"]["total"], 101)
        lines = self.api.get(f"/api/pars/{PAR}/financials/lines").json()
        self.assertIn(("fy15", 100), {(x["column_id"], x["amount"]) for x in lines})


if __name__ == "__main__":
    unittest.main(verbosity=2)
