import { useCallback, useState } from 'react';
import FinancialsTab from './features/financials/FinancialsTab';
import ChatPanel from './features/chat/ChatPanel';
import { useStored } from './state/useStored';

const TABS = [
  ['overview', 'Overview'],
  ['requirements', 'Requirements'],
  ['financials', 'Financials'],
  ['approvals', 'Approvals'],
];
const CHAT_WIDTH = 360;
const INTRO = [{
  id: 'intro', role: 'bot',
  text: 'Hi! For the Financials tab you can attach a filled PAR Excel file (📎 or drag it here) or paste rows copied from Excel – '
    + 'they open in the import review on the right, where you check where every row goes before applying. '
    + 'You can also type straight into the grid.',
}];

/** Workbench layout: chat on the left, the PAR tabs (Financials) on the right */
export default function App() {
  const parId = 'PAR-2026-014';
  const [tab, setTab] = useState('financials');
  const [chatOpen, setChatOpen] = useStored('par.chatOpen', true);
  const [chatW, setChatW] = useStored('par.chatWidth', CHAT_WIDTH);
  const [messages, setMessages] = useState(INTRO);
  const [inbox, setInbox] = useState(null); // a file / pasted rows handed to the Financials tab

  const post = useCallback((m) => setMessages((ms) => [...ms, { id: `${Date.now()}-${Math.random()}`, ...m }]), []);
  const toFinancials = (item) => { setTab('financials'); setInbox({ ...item, at: Date.now() }); };

  return (
    <div className="app">
      <header className="appbar">
        <span className="logo">PAR Workbench</span>
        <span className="par"><b>{parId}</b> · Customer Onboarding Automation</span>
        <span className="sp" />
        {!chatOpen && <button className="pill btnlike" onClick={() => setChatOpen(true)}>💬 Show chat</button>}
        <span className="pill">Draft</span>
      </header>
      <div className="workspace">
        {chatOpen && (
          <>
            <div className="chatcol" style={{ width: chatW }}>
              <ChatPanel
                messages={messages}
                onClose={() => setChatOpen(false)}
                onSend={(text) => {
                  post({ role: 'user', text });
                  post({ role: 'bot', text: 'The chat assistant isn’t connected in this prototype. Attach an Excel file (📎) or paste rows copied from Excel to bring them into Financials.' });
                }}
                onAttach={(file) => {
                  post({ role: 'user', file: { name: file.name, size: file.size } });
                  post({ role: 'system', text: `Opened ${file.name} in the Financials import review →` });
                  toFinancials({ kind: 'file', file });
                }}
                onPasteTable={(text) => post({ role: 'user', table: text })}
                onImportText={(text) => { post({ role: 'system', text: 'Opened the pasted rows in the Financials import review →' }); toFinancials({ kind: 'text', text }); }}
              />
            </div>
            <Splitter width={chatW} onChange={setChatW} />
          </>
        )}
        <section className="main">
          <nav className="tabs">
            {TABS.map(([k, l]) => (
              <button key={k} className={`tab${tab === k ? ' on' : ''}`} onClick={() => setTab(k)}>{l}</button>
            ))}
          </nav>
          <main className="page">
            {/* the tab mounts only when opened → it fetches template + saved data on open */}
            {tab === 'financials'
              ? <FinancialsTab parId={parId} inbox={inbox} onInboxDone={() => setInbox(null)} onActivity={post} />
              : <div className="placeholder">{TABS.find((t) => t[0] === tab)[1]} tab – not part of this prototype. Open <b>Financials</b>.</div>}
          </main>
        </section>
      </div>
    </div>
  );
}

/** drag to resize the chat column, double-click to reset */
function Splitter({ width, onChange }) {
  const onPointerDown = (e) => {
    e.preventDefault();
    const startX = e.clientX, startW = width;
    const move = (ev) => onChange(Math.max(280, Math.min(Math.round(window.innerWidth * 0.5), startW + ev.clientX - startX)));
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      document.body.classList.remove('resizing');
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
    document.body.classList.add('resizing');
  };
  return <div className="splitter" role="separator" aria-orientation="vertical" title="Drag to resize · double-click to reset"
    onPointerDown={onPointerDown} onDoubleClick={() => onChange(CHAT_WIDTH)} />;
}
